<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateParserCategoriesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('parser_categories', function (Blueprint $table) {
            $table->id();

            $table->unsignedBigInteger('sklad_id')->unsigned();
            $table->foreign('sklad_id')->references('id')->on('sklads')->onDelete('cascade');

            $table->unsignedBigInteger('parent_id')->unsigned();
            $table->foreign('parent_id')->references('id')->on('parser_categories')->onDelete('cascade');

            $table->string('title');
            $table->string('url');

            $table->integer('status')->default(0);

            $table->string('fields')->default(null);
            $table->integer('is_edited')->default(null);

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('parser_categories');
    }
}
