<?php


namespace App\Exports;


use App\Models\CustomCategory;
use App\Models\ParseProduct;
use App\Models\ParserCategory;
use App\Models\ProductFieldReplace;
use App\Models\Sklad;
use Illuminate\Support\Facades\Log;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithChunkReading;
use Maatwebsite\Excel\Concerns\WithTitle;

class ProductsSheet implements FromArray, WithTitle, WithChunkReading
{

    private $skladId;
    private $categoryId;

    public function __construct($skladId, $categoryId)
    {
        $this->skladId = $skladId;
        $this->categoryId = $categoryId;
    }

    public function array(): array
    {
        $data = ParseProduct::where([
            ["sklad_id", $this->skladId],
            ["category_id", $this->categoryId]
        ])->get();

        if ($data) {
            $prod = [];
//            $header = ['id', 'sklad', 'title', 'category', 'price', 'slug'];
            $headerRus = ['Название', 'Категория'];
            $cat_id = $this->categoryId;
            $sklad = Sklad::where('id', $this->skladId)->first();
            $customCat = CustomCategory::getCustomCategoryById($cat_id, $sklad );
            foreach ($data as $key => $d) {
                $prod[$key] = [];
                $prod[$key]['title'] = $d->title;
                $prod[$key]['category'] = $customCat;
                $categoryPath = ProductFieldReplace::getCategooryPath($cat_id);

                $fields = $d->field ?? "";
                if($categoryPath && $fields){
                    $replace = ProductFieldReplace::where("category_path", $categoryPath)->get();
//                    dd($replace);
                    if ($replace) {
                        foreach ($replace as $item) {
                            if(strripos($fields, $item->title_old) !== false) {
                                $fields = str_replace($item->title_old, $item->title, $fields);
                            }
                        }
                    }
                }
                $fields = json_decode($fields, JSON_UNESCAPED_UNICODE);

                foreach ($fields as $keyp => $fp){
                    if(strripos($keyp, "-") === false) {
                        $prod[$key][$keyp] = $fp;
                        if (!in_array($keyp, $headerRus)) $headerRus[] = $keyp;
                    }
                }


            }
        }
        array_unshift($prod, $headerRus);
        return $prod;

    }

    public function title(): string
    {
        return ParserCategory::getCategoryTitle($this->categoryId);
    }

    public function chunkSize(): int
    {
        return 100;
    }

    public function getCategoryChain($category_id, $category_array = []) {
        $category = ParserCategory::where('id', $category_id)->first();
        if($category) {
            $category_array[] = $category->title;
            if($category->parent_id) {
                $category_array = $this->getCategoryChain($category->parent_id, $category_array);
            }
        }
        return $category_array;
    }
}
