<?php

namespace App\Exports;

use App\Models\ParseProduct;
use App\Models\ParserCategory;
use Maatwebsite\Excel\Concerns\Exportable;
use Maatwebsite\Excel\Concerns\FromArray;
use Maatwebsite\Excel\Concerns\WithMultipleSheets;

class ProductsExport implements FromArray, WithMultipleSheets
{
    use Exportable;
    private $skladId;

    public function __construct($skladId)
    {
        $this->skladId = $skladId;
    }


    public function array(): array
    {
        return $this->sheets();
    }

    public function sheets(): array
    {
        $sheets = [];
        $skladId = $this->skladId;
        if($skladId) {
            $category_ids = ParseProduct::where('sklad_id', $skladId)->select('category_id')->groupBy('category_id')->get()->pluck('category_id');
            if($category_ids) {
                foreach ($category_ids as $cids) {
                    $category = ParserCategory::where('id', $cids)->first();
                    if($category) {
                        $sheets[] = new ProductsSheet($skladId, $cids);
                    }
                }
            }
        }
        return $sheets;
    }

}
