<?php

namespace App\Http\Controllers;

use App\Exports\ProductsExport;
use App\Jobs\ExportProduct;
use App\Jobs\ProcessParse;
use App\Models\Alert;
use App\Models\CustomCategory;
use App\Models\Notification;
use App\Models\ParseProduct;
use App\Models\Parser;
use App\Models\ParserCategory;
use App\Models\ProductFieldReplace;
use App\Models\Provider;
use App\Models\Sklad;
use App\Models\Parser\MCru;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Log;
use Maatwebsite\Excel\Facades\Excel;

class SkladController extends Controller
{
    public function index() {
        $sklad = Sklad::orderBy('provider_id')->get();
        $sklad = Sklad::getSkladCategoryProdCount($sklad);
        return view('sklad.index', [
            'sklad' => $sklad
        ]);
    }

    public function show(Sklad $sklad, Request $request) {

        $categoryId = $request->input('category_id') ?? null;

        $skaldId = $sklad->id;

        $status = Alert::getAlertStatus($skaldId);

        $parentCat = ParserCategory::getParentCategories($categoryId, $skaldId);

        $parentCat = ParserCategory::addHasChildrenProp($parentCat, $skaldId);

//        $parentCat = ParserCategory::getProductCountInCategory($parentCat, $skaldId);

        $breadcrump = $this->getCategoryChildChain($categoryId);

        $parentCat = CustomCategory::getCustomCategory($parentCat, $breadcrump, $sklad);

        $products = ParseProduct::getProductsByCategory($categoryId);

        $fields = ProductFieldReplace::getFieldsByCategoryId($categoryId);

        $catCount = ParserCategory::getCategoryCount($skaldId);

        $prodCount = ParseProduct::getProductCount($skaldId);

        $notification = Notification::getExportNotifications($skaldId);

        return view('sklad.show', [
            'sklad' => $sklad,
            'status' => $status,
            'category' => $parentCat,
            'breadcrump' => $breadcrump,
            'products' => $products,
            'fields' => $fields,
            'productCount' => $prodCount,
            'categoryCount' => $catCount,
            'notification' => $notification
        ]);

    }

    public function create(Request $request) {
        $providerId = $request->input('provider');
        if($providerId) {
            $providerSelected = Provider::where('id', $providerId)->first();
        }
        $provider = Provider::get();
        return view('sklad.create', [
            'sklad' => [],
            'provider' => $provider,
            'providerSelected' => $providerSelected ?? []
        ]);
    }

    public function store(Request $request) {
        $title = $request->input('title');
        $rez = [
            'rez' => 0,
            'desc' => 'Ошибка сервера'
        ];
        if($title) {
            Sklad::create($request->all());
            $rez = [
                'rez' => 1,
                'desc' => 'Склад добавлен'
            ];
        } else {
            $rez['desc'] = 'Заполните название';
        }
        return back()->with((($rez['rez']) ? 'success' : 'error'), $rez['desc']);
    }

    public function edit(Sklad $sklad) {
        $provider = Sklad::getProviderBySkladId($sklad->id);
        return view('sklad.edit',[
            "provider" => $provider ?? "",
            "sklad" => $sklad
        ]);
    }

    public function update(Request $request, Sklad $sklad) {
        try {
            $sklad->update($request->all());
            return back()->with('success', "Склад изменен");
        } catch (\Exception $e) {
            return back()->with('error', "Ошибка");
        }
    }

    public function apiSkladGet(Request $request) {
        $id = $request->input('id');

        $sklad = Sklad::where('id', $id)->first();

        if($sklad) {

            $all = [];
            $parserModal = new Parser;
//            $parser = $parserModal->request('https://mc.ru/prices/filials/price_hab.htm');
            $parser = $parserModal->request($sklad->site);

            preg_match_all('~<table>(.*?)</table>~is', $parser, $table);

            if (!empty($table[0])) {
                foreach ($table[0] as $tabl) {
                    preg_match_all('~<tr>(.*?)</tr>~is', $tabl, $tr);
                    if (!empty($tr[0])) {
                        $categoryName = '';
                        $fieldName = [];
                        $prod = [];
                        foreach ($tr[0] as $tKey => $t) {
                            if ($tKey == 0) {
                                preg_match('~<th (.*?)>(.*?)</th>~is', $t, $tCategoryName);
                                if (!empty($tCategoryName[2])) {
                                    $categoryName = $tCategoryName[2];
                                }
                            } else if ($tKey == 1) {
                                preg_match_all('~<th>(.*?)</th>~is', $t, $tFieldName);
                                if (!empty($tFieldName[1])) {
                                    foreach ($tFieldName[1] as $fieNaA) {
//                                    $fieldName[] = urlencode($fieNaA);
                                        $fieldName[] = $fieNaA;
                                    }
                                }
                            } else {
                                preg_match_all('~<td>(.*?)</td>~is', $t, $tProd);
                                if (!empty($tProd[1])) {
                                    $prod[] = $tProd[1];
                                }
                            }
                        }
                        $categoryNameOb = [
                            'id' => 0,
                            'parent_id' => 0,
                            'title' => $categoryName
                        ];
                        $newCategoryName = $parserModal->getCategory(0, $categoryName);
                        if (!empty(reset($newCategoryName)['title'])) {
                            $categoryNameOb = [
                                'id' => reset($newCategoryName)['id'],
                                'parent_id' => reset($newCategoryName)['parent_id'],
                                'title' => reset($newCategoryName)['title']
                            ];
                        }
                        $fieldQuery = http_build_query(array('field' => $fieldName));
                        $parserHead = $parserModal->request('https://baza.tnmk.ru/api/out/category/get/field?id=' . ($categoryNameOb['id'] ?? 0) . '&' . $fieldQuery);
                        $category = [
                            'category' => $categoryNameOb,
                            'head' => json_decode($parserHead, true),
                            'prods' => $prod
                        ];

                        $all[] = $category;

                    }
                    break;
                }

            }
        } else {
            $all = [
                'rez' => 0,
                'desc' => 'Склад не найден'
            ];
        }
        return $all;
    }

    public function parsing(Sklad $sklad) {
        $skladId = $sklad->id ?? 0;
        if($skladId) {
            if($this->isNodeParse($sklad)) {
                $this->nodeParse($sklad);
                return back();
            } else {
                ProcessParse::dispatch($skladId);
                return back();
            }


        } else {
            return abort(404);
        }
    }

    public function refreshCategories(Sklad $sklad) {
        $skladId = $sklad->id ?? 0;
        if($skladId) {

            if($this->isNodeParse($sklad)) {
                $this->refreshNodeParse($sklad);
            } else {
                ProcessParse::dispatch($skladId, 1);
                return back();
            }

        } else {
            return abort(404);
        }
    }

    public function isNodeParse($sklad){
        if($sklad->site){
            if(strripos($sklad->site, 'severstal') !== false) {
                return true;
            } else {
                return false;
            }
        }
    }

    public function nodeParse($sklad){
        if($sklad->site){
            if(strripos($sklad->site, 'severstal') !== false) {
                $ss = new Parser\Severstal($sklad->id);
                $ss->parsing();
            }
        }
    }

    public function refreshNodeParse($sklad)
    {
        if($sklad->site){
            if(strripos($sklad->site, 'severstal') !== false) {
                $ss = new Parser\Severstal($sklad->id);
                $ss->refreshCategories();
            }
        }
    }

    public function getCategoryChildChain($id, $chain_ch = []) {
        $chain = ParserCategory::where('id', $id)->select('id', 'title', 'parent_id', 'url')->first();
        if($chain) {
            $chain = $chain->toArray();
            array_unshift($chain_ch, [
                'parent_id' => $chain['parent_id'],
                'title' => $chain['title'],
                'url' => $chain['url'],
                'id' => $id
            ]);
        }
        if(!empty($chain['parent_id'])) {
            return $this->getCategoryChildChain($chain['parent_id'], $chain_ch);
        }
        return $chain_ch;
    }

    public function editCategoryTitle(Request $request) {
        $title = $request->input('title') ?? "";
        $oldTitle = $request->input('oldTitle') ?? "";
        $categoryId = $request->input('id') ?? null;
        if($title) {
            $response = ParserCategory::setCategoryTitleReplaceByTitle($categoryId, $title, $oldTitle);
        }
        return $response;
    }

    public function editFieldsTitle(Request $request) {
        $field = $request->input('field') ?? [];
        $oldField = $request->input('oldField') ?? "";
        $categories = $request->input('categories') ?? [];
        $response = ProductFieldReplace::setField($categories, $field, $oldField);
        return $response;
    }

    public function removeExportNotivication(Request $request){
        $id = $request->input('id') ?? "";
        if(!empty($id)){
            return Notification::removeExportNotification($id);
        } else {
            return  json_encode(500);
        }
    }

    public function setCustomCategory(Request $request) {
        $id = $request->input('id');
        $title = $request->input('title');
        $categoryTitle = $request->input('categoryTitle');
        $oldTitle = $request->input('oldTitle');
        $categories = $request->input('categories');
        if($categoryTitle && $title) {
            return CustomCategory::setCategory($id, $title, $categoryTitle, $oldTitle, $categories);
        } else {
            return json_encode(500);
        }
    }

    public function export(Sklad $sklad) {
        $skladId = $sklad->id ?? 0;
        if($skladId) {
            $notifyId = Notification::insertGetId([
                'type' => 'export',
                'sklad_id' => $skladId,
                'status' => 1,
                'value' => '<div class="spinner-border text-primary m-1" role="status">
                            <span class="sr-only">Loading...</span>
                            </div>
                            <br>Экспорт начался <br>'.date('Y-m-d H:i:s', strtotime('5 hour'))
            ]);
            ExportProduct::dispatch($skladId, $notifyId);
            return back();
        } else {
            return abort(404);
        }

    }

    public function exportProdFile($filename) {
        if($filename) {
            $file = storage_path('app/'.$filename);
            if (file_exists($file)) {
                header ("Content-Type: application/octet-stream");
                header ("Accept-Ranges: bytes");
                header ("Content-Length: ".filesize($file));
                header ("Content-Disposition: attachment; filename=".$filename);
                readfile($file);
            }
        }
    }


}
