<?php

namespace App\Http\Controllers;

use App\Models\Provider;
use App\Models\Sklad;
use Illuminate\Http\Request;

class ProviderController extends Controller
{
    public function index(Request $request) {

        $provider = Provider::get();

        return view('provider.index', [
            'provider' => $provider ?? []
        ]);
    }

    public function show(Provider $provider) {
        $provider->sklads = Sklad::getSkladCategoryProdCount($provider->sklads);
        return view('provider.show', [
            'provider' => $provider
        ]);
    }

    public function create() {
        return view('provider.create', [
            'provider' => []
        ]);
    }

    public function store(Request $request) {
        $title = $request->input('title');
        $rez = [
            'rez' => 0,
            'desc' => 'Ошибка сервера'
        ];
        if($title) {
            $provider = Provider::where('title', $title)->first();
            if($provider) {
                $rez['desc'] = 'Такой поставщик уже есть';
            } else {
                Provider::create($request->all());
                $rez = [
                    'rez' => 1,
                    'desc' => 'Поставщик добавлен'
                ];
            }
        } else {
            $rez['desc'] = 'Заполните название';
        }
        return back()->with((($rez['rez']) ? 'success' : 'error'), $rez['desc']);
    }

    public function edit(Provider $provider) {
        return view('provider.edit',[
            "provider" => $provider
        ]);
    }

    public function update(Request $request, Provider $provider) {
        try {
            $provider->update($request->all());
            return back()->with('success', 'Провайдер изменен');
        } catch (\Exception $exception) {
            return back()->with('error', 'Ошибка');
        }

    }

}
