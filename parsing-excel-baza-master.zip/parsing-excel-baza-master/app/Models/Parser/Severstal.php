<?php

namespace App\Models\Parser;

use App\Models\Alert;
use App\Models\ParseProduct;
use App\Models\ParserCategory;
use App\Models\Sklad;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Route;
use simplehtmldom\HtmlDocument;

class Severstal extends Model
{
    use HasFactory;

    private $PRICE;
    private $SITE;
    protected $skladId;

    public function __construct($skladId)
    {
        $this->skladId = $skladId;
        $this->SITE = $this->getSite();
    }

    public function parsing() {
        if($this->skladId) {
            $skladId = $this->skladId;
            $sklad = Sklad::find($skladId);
            if($sklad) {
                $alertId = Alert::startParsing($skladId);
                $this->sendNodeRequest();
            }
        }
    }

    public function sendNodeRequest() {
        $this->getPage('http://141.101.196.167:5050/api/parse/'.$this->skladId, 0);
//        $this->getPage('http://127.0.0.1:3356/api/parse/'.$this->skladId, 0);
        return 1;
    }

    public function refreshCategories() {
        Log::info("============================refresf============================");
        $this->removeAll();
        $this->parsing();
//        Alert::stopParsing($alertId);
    }

    private function getSite() {
        $sklad = Sklad::where('id', $this->skladId)->first();
        if($sklad)
            $site = strripos($sklad->site, "/ru/ru") === false ? $sklad->site."ru/ru" : $sklad->site;
        return $site;
    }

    private function removeAll() {
        ParseProduct::removeAllProducts($this->skladId);
        ParserCategory::removeAllCategory($this->skladId);
    }

    private function setCategoriesFromDom() {
//        $responce = $this->getPage('https://market.severstal.com/rest/v2/severstal/products/search?view=list&pageSize=1&sort=name-asc&catalogId=severstalByTypeInStockProductCatalog&categoryCode=96&lang=ru&curr=RUB', 1) ;
//        $responce = json_decode($responce, JSON_UNESCAPED_UNICODE);
//        dd($responce['pagination'], empty($responce['errors']));
        try {
//            $response = simplexml_load_file('https://market.severstal.com/ru/ru/sitemap-0.xml');
            $response = $this->getPage('https://market.severstal.com/ru/ru/sitemap-0.xml');
//            $response = json_decode($response, JSON_UNESCAPED_UNICODE);
            dd($response);
            $resultArr = $this->getCategoryLinksFromSitemap($response);
            if (!empty($resultArr)) {
                ParserCategory::insert($resultArr);
            }
        } catch (\Exception $e) {
            dd($e);
        }

    }

    private function setCategoriesAndProducts(){

        $category = ParserCategory::where([
            ["sklad_id", $this->skladId],
            ["status", 0]
        ])->get();
//        $count = [];
//        $categoryId = [];
        if($category){
            foreach ($category as $cat) {
                if($cat->url){
                    $catChildCatExist = $this->isChildCategory($cat->url);
                    $categoryId = $this->getCatIdFromUrl($cat->url);
                    $count = $this->getProductCount($categoryId, $catChildCatExist);
                    Log::info("cat Id - ". $categoryId . " count - ".$count);
                    if($catChildCatExist) {
                        $responce = $this->getPage('https://market.severstal.com/rest/v2/severstal/products/search?view=list&pageSize='.$count.'&sort=name-asc&catalogId=severstalByTypeInStockProductCatalog&categoryCode='.$categoryId.'&lang=ru&curr=RUB', 1) ;
                        $responce = json_decode($responce, JSON_UNESCAPED_UNICODE);
                    } else {
                        $responce = $this->getPage('https://market.severstal.com/rest/v2/severstal/products/search?view=list&pageSize='.$count.'&sort=name-asc&catalogId=severstalByTypeInStockProductCatalog&excerptCode='.$categoryId.'&lang=ru&curr=RUB', 1);
                        $responce = json_decode($responce, JSON_UNESCAPED_UNICODE);
                    }
                    dd($responce);
                    $this->setProductsFromJSON($responce, $cat);
                    sleep(1);
                }
            }
        }
    }

    private function setProductsFromJSON($response, $cat){
        dd($response, $response['products'], $cat);
        if(!empty($response['products'])){
            $prodArr = [];
            foreach ($response['products'] as $prod){
                $title = !empty($prod['name']) ? $prod['name'] : "";
                $link = !empty($prod['url']) ? $prod['url'] : "";
                Log::info($title. " --- ".$link);

                dd($prod);
                $this->setCategoryFromJSON($prod, $cat);

                $prodArr[] = [
                    "title" => $title,
                    "slug" => $link,
//                    "field" => json_encode($fieldsProd, JSON_UNESCAPED_UNICODE),
                    "price" => "",
                    "unit" => null,
                    "sklad_id" => $this->skladId,
                    "category_id" => $cat->id
                ];

            }
        }
    }

    private function setCategoryFromJSON($response, $cat){
        if(!empty($response["categories"])) {
            if(count($response["categories"]) > 1) {
                $url = $response["categories"][1]['url'];
                $category = ParserCategory::where([
                    ['url', $url],
                    ['sklad_id', $this->skladId]
                ])->first();
                if($category) {
                    $category->title = !empty($response["categories"][1]["name"]) ? $response["categories"][1]["name"] : "";
                    $category->save();
                    Log::info("parent category - ".$category->title);
                    $cat->title = !empty($response["categories"][0]["name"]) ? $response["categories"][0]["name"] : "";
                    Log::info("category - ".$category->title);
                    $cat->parent_id = $category->id;
                    $cat->status = 1;
                    $cat->save();
                } else {
                    $title = $response["categories"][1]['name'];
                    $url = $response["categories"][1]['url'];
                    $resultArr = [
                        "title" => $title,
                        "url" => $url,
                        "parent_id" => null,
                        "sklad_id" => $this->skladId,
                        "status" => 1,
                    ];
                    $catId = ParserCategory::insertGetId($resultArr);
                    Log::info("new par category - ".$title);
                    $cat->title = !empty($response["categories"][0]["name"]) ? $response["categories"][0]["name"] : "";
                    Log::info("category 2 - ".$category->title);
                    $cat->parent_id = $catId;
                    $cat->status = 1;
                    $cat->save();
                }
            }
            if(count($response["categories"]) == 1) {
                $cat->title = !empty($response["categories"][0]["name"]) ? $response["categories"][0]["name"] : "";
                Log::info("simple category".$cat->title);
                $cat->status = 1;
                $cat->save();
            }
        }
    }

    private function getCatIdFromUrl($url){
        $result = "";
        if($url) {
            $strArr = explode("/", $url);
            $length = count($strArr);
            $result = $strArr[$length-1];
        }
        return $result;
    }

    private function getProductCount($categoryId, $catChildCatExist) {
        $count = 0;
        if($catChildCatExist) {
            $responce = $this->getPage('https://market.severstal.com/rest/v2/severstal/products/search?view=list&pageSize=1&sort=name-asc&catalogId=severstalByTypeInStockProductCatalog&categoryCode='.$categoryId.'&lang=ru&curr=RUB', 1) ;
            $responce = json_decode($responce, JSON_UNESCAPED_UNICODE);
        } else {
            $responce = $this->getPage('https://market.severstal.com/rest/v2/severstal/products/search?view=list&pageSize=1&sort=name-asc&catalogId=severstalByTypeInStockProductCatalog&excerptCode='.$categoryId.'&lang=ru&curr=RUB', 1);
            $responce = json_decode($responce, JSON_UNESCAPED_UNICODE);
        }
        Log::info($responce['errors'] ?? "not error");
        Log::info($responce['pagination'] ?? "paginateion");
        if(empty($responce['errors'])) {
            $count = $responce['pagination']["totalResults"];
        }
        return $count ?? 0;
    }

    private function getCategoryLinksFromSitemap($response)
    {
        $result = [];
        foreach ($response as $item) {
            $link = strripos($item->loc[0], "/o/c/") !== false || strripos($item->loc[0], "/o/e/") !== false ? $item->loc[0] : "";
            $link = trim($link);
            $link = str_replace($this->SITE, "", $link);
            if($link) {
                $result[] = [
                    "title" => "",
                    "url" => $link,
                    "parent_id" => null,
                    "sklad_id" => $this->skladId,
                    "status" => 0,
                ];
            }
        }
        Log::info("Sitemap - ". $link);
        return $result;
    }

    private function setProducts() {

    }

    private function getPage($url, $isJson = 0) {
        $post = 0;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url); // отправляем на

        $agentArr = [
            'Mozilla/5.0 (compatible; YandexTurbo/1.0; +http://yandex.com/bots)',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121 Safari/537.36',
            'Mozilla/5.0 (iPhone; CPU iPhone OS 8_1 like Mac OS X) AppleWebKit/600.1.4 (KHTML, like Gecko) Version/8.0 Mobile/12B411 Safari/600.1.4 (compatible; YandexMobileBot/3.0; +http://yandex.com/bots)',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/72.0.3626.121* Safari/537.36 (compatible; YandexScreenshotBot/3.0; +http://yandex.com/bots)',
            'Mozilla/5.0 (compatible; YandexTurbo/1.0; +http://yandex.com/bots)'
        ];
        $randIndex = array_rand($agentArr);
        $agent = $agentArr[$randIndex];
        $agent = 'Mozilla/5.0 (compatible; YandexTurbo/1.0; +http://yandex.com/bots)';
        if($isJson){
            curl_setopt($ch, CURLOPT_USERAGENT, $agent);
            curl_setopt($ch, CURLOPT_HTTPHEADER, [
                'Content-Type: application/json'
            ]);
        } else {
            curl_setopt($ch, CURLOPT_HEADER, true); // пустые заголовки
        }

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); // возвратить то что вернул сервер
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 3); // следовать за редиректами
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);// таймаут4
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_ENCODING ,"");
        curl_setopt($ch, CURLOPT_POST, $post!==0 ); // использовать данные в post
//        curl_setopt($ch, CURLOPT_HTTPHEADER, array("Cookie: locationNewThree=".$location.";")); //отправка куки с кодом локации
        if($post)
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        $data = curl_exec($ch);
        curl_close($ch);

        return $data;
    }

    private function isChildCategory($url) {
        if(!empty($url)) {
            if(strripos($url, "/c/") !== false) {
                return true;
            }
            if(strripos($url, "/e/") !== false) {
                return false;
            }
        }
    }


}
