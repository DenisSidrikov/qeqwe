<?php

namespace App\Models\Parser;

use App\Models\Alert;
use App\Models\ParseProduct;
use App\Models\ParserCategory;
use App\Models\Sklad;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Log;
use simplehtmldom\HtmlDocument;

class Metallotorg extends Model
{
    use HasFactory;

    private $CATALOGURL = 'https://www.metallotorg.ru/info/metalloprokat/';
    private $SITE = 'https://www.metallotorg.ru';
    private $SITE_PRICE = 'https://www.metallotorg.ru/info/pricelists/price_detail/';
    protected $skladId;
    protected $sklad;

    public function __construct($skladId)
    {
        $this->skladId = $skladId;
    }

    public function parsing($skladId = 0) {
        $skladId = $this->skladId;
        if($this->skladId) {
            $sklad = Sklad::find($skladId);
            if($sklad) {
                $alertId = Alert::startParsing($skladId);
                $this->setCategoriesFromForm();
                $this->setProductsFromForm();
                Alert::stopParsing($alertId);
            }
        }
    }

    private function setCategoriesFromForm() {
        $sklad = Sklad::find($this->skladId);
        $this->sklad = $sklad;
        $locationCode = $this->getLocationCode($sklad);
        $pageUrl = $this->SITE_PRICE.$locationCode.'/all/';
        $response = $this->getPage($pageUrl);
        $response = new HtmlDocument($response);
        $select = $response->find('#se_tname option');
        if($select) {
            foreach ($select as $opt) {
                $title = $opt->innertext;
                $slug = $this->getCatParameters($title);
                if(strripos($title, "Все группы") === false) {
                    $parresultArr = [
                        "title" => $title,
                        "url" => $slug,
                        "parent_id" => null,
                        "sklad_id" => $this->skladId,
                        "status" => 0,
                    ];
                    ParserCategory::insert($parresultArr);
                }
            }

        }
    }

    private function setProductsFromForm() {
        $category = ParserCategory::where([
            ['sklad_id', $this->skladId],
            ['status', 0]
        ])->get();

        if($category) {
            $locationCode = $this->getLocationCode($this->sklad);
            foreach ($category as $cat) {
                $url = $cat->url;
                $paramEncod = mb_convert_encoding($url, "windows-1251");
                $pageStr = $this->getPage($this->SITE_PRICE.$locationCode.'/all/', array("p_page" => 1, "se_fil" => $locationCode, "se_tname" => $paramEncod, 'se_dir' => 'all'));

                $response = new HtmlDocument($pageStr);
                $paginate = $response->find('.Title_admin3b');
                if($paginate) {
                    Log::info("paginateProductParse");
                    $this->productParse($response, $cat);
                    $this->paginateProductParse($response, $cat, $locationCode);
                } else {
                    Log::info("parameters");
                    $this->productParse($response, $cat);
                }

            }
        }

    }

    private function setCategoriesFromDom() {
        $response = $this->getPage($this->CATALOGURL);
        $response = new HtmlDocument($response);
        $html = $response->find('.news-box > .item');
        if(!empty($html)) {
            foreach ($html as $item) {
                $title = $item->find('h3>a>strong', 0);
                $slug = $item->find('h3 > a', 0);
                $parresultArr = [
                    "title" => $title ? $title->innertext : "",
                    "url" => $slug ? $slug->attr['href'] : "",
                    "parent_id" => null,
                    "sklad_id" => $this->skladId,
                    "status" => 0,
                ];
                $parentid = ParserCategory::insertGetId($parresultArr);
                $childCat = $item->find('.goods ul li a');
                if(!empty($childCat)) {
                    foreach ($childCat as $dom){
                        $cresultArr = [
                            "title" => $dom->innertext,
                            "url" => $dom->attr['href'],
                            "parent_id" => $parentid,
                            "sklad_id" => $this->skladId,
                            "status" => 0,
                        ];
                        ParserCategory::insert($cresultArr);
                    }
                }

            }
        }
    }

    private function getCatParameters($title) {

        if(strripos($title, "Арматура рифленая А3") !== false) {
            return "Арм1";
        }

        if(strripos($title, "Арматура гладкая А1") !== false) {
            return "Арм2";
        }

        if(strripos($title, "Арматура АТ800") !== false) {
            return "Арм3";
        }

        if(strripos($title, "Балка двутавровая") !== false) {
            return "Балка";
        }

        if(strripos($title, "Катанка") !== false) {
            return "Катанка";
        }

        if(strripos($title, "Квадрат стальной") !== false) {
            return "Квадрат";
        }

        if(strripos($title, "Круг нержавеющий") !== false) {
            return "Круг2";
        }

        if(strripos($title, "Круг") !== false) {
            return "Круг1";
        }

        if(strripos($title, "Лист горячекатаный") !== false) {
            return "Лист1";
        }

        if(strripos($title, "Лист холоднокатаный") !== false) {
            return "Лист2";
        }

        if(strripos($title, "Лист низколегированный") !== false) {
            return "Лист3";
        }

        if(strripos($title, "Лист оцинкованный") !== false) {
            return "Лист4";
        }

        if(strripos($title, "Лист рифленый") !== false) {
            return "Лист5";
        }

        if(strripos($title, "Лист просечновытяжной") !== false) {
            return "Лист6";
        }

        if(strripos($title, "Поковка") !== false) {
            return "Поковка";
        }

        if(strripos($title, "Полоса") !== false) {
            return "Полоса";
        }

        if(strripos($title, "Проволока") !== false) {
            return "Проволока";
        }

        if(strripos($title, "Сетка") !== false) {
            return "Сетка";
        }

        if(strripos($title, "Трубы водогазопроводные") !== false) {
            return "Труба ВГП";
        }

        if(strripos($title, "Трубы электросварные") !== false) {
            return "Труба ЭС";
        }

        if(strripos($title, "Труба бесшовная") !== false) {
            return "Труба БШ";
        }

        if(strripos($title, "Трубы профильные") !== false) {
            return "Труба проф";
        }

        if(strripos($title, "Уголок стальной") !== false) {
            return "Уголок";
        }

        if(strripos($title, "Швеллер гнутый") !== false) {
            return "Швеллер2";
        }

        if(strripos($title, "Швеллер") !== false) {
            return "Швеллер1";
        }

        if(strripos($title, "Шестигранник") !== false) {
            return "Шестигранник";
        }

        return "";

    }

    private function setProducts(){

        $sklad = Sklad::find($this->skladId);
        $locationCode = $this->getLocationCode($sklad);

        $category = ParserCategory::where([
            ['sklad_id', $this->skladId],
            ['status', 0]
        ])->get();

        $category = ParserCategory::addHasChildrenProp($category, $this->skladId);

        if($category) {
            foreach ($category as $cat) {
                $pageStr = $this->getPage($this->SITE.$cat->url, array("p_page" => 1, "se_fil" => $locationCode));
                $response = new HtmlDocument($pageStr);
//                $this->productParse($response, $cat);
                if(!empty($cat->url)  && $cat->hasChildren == false) {
                    $parameters = $response->find('#se_name option');
                    if($parameters && count($parameters) > 1) {
                        foreach ($parameters as $parameter) {
                            $valueParam = $parameter->attr['value'] ? $parameter->attr['value'] : $parameter->innertext;
                            $pageStr = $this->getPage($this->SITE.$cat->url, array("p_page" => 1, "se_fil" => $locationCode, "se_name" => $valueParam));
                            $response = new HtmlDocument($pageStr);
                            $paginate = $response->find('.Title_admin3b');
                            if($paginate) {
                                Log::info("paginateProductParse");
                                $this->productParse($response, $cat);
                                $this->paginateProductParse($response, $cat, $locationCode, $valueParam);
                            } else {
                                Log::info("parameters");
                                $pageStr = $this->getPage($this->SITE.$cat->url, array("p_page" => 1, "se_fil" => $locationCode, "se_name" => $valueParam));
                                $response = new HtmlDocument($pageStr);
                                $this->productParse($response, $cat);
                            }
                        }
                    } else {
                        Log::info("simplepage");
                        $this->productParse($response, $cat);
                    }


                }
            }
        }
    }

    private function paginateProductParse($response, $cat, $locationCode, $valueParam = "") {
        // 1 2 3 4 >>     1 2 3 [4] 5 6 7 >>    9 10 11 [12] 13 14 15 >>    16 17 18 [19] 20 21 22 >>    17 18 19 [20] 21 22
        $pagArrow = $response->find('table a b');
        if($pagArrow && is_array($pagArrow)) {
            $pagArrow = $pagArrow && count($pagArrow) > 1 ? $pagArrow[1] : $pagArrow[0];
            $pagArrowText = $pagArrow ? $pagArrow->innertext : "";
        } else {
            $pagArrow = '1';
            $pagArrowText = '1';
        }

        $logcount = 1;
        $maxCount = 50;

        while($pagArrow && $logcount < $maxCount) {
            if(strripos($pagArrowText, "Посмотреть далее") !== false) {
                $logcount++;
            } else {
                $paginateCur = $response->find('.Title_admin3b');
                $lastPage = end($paginateCur);
                $maxCount = $lastPage->innertext;
                $maxCount = (int)$maxCount;
                $logcount++;
                Log::info("maxCount - ".$maxCount);
            }
            $url = $cat->url;
            $paramEncod = mb_convert_encoding($url, "windows-1251");
            $pageStr = $this->getPage(
                $this->SITE_PRICE.$locationCode.'/all/'.$logcount.'/',
                array("p_page" => $logcount, "se_fil" => $locationCode, "se_tname" => $paramEncod, 'se_dir' => 'all')
            );
            $response = new HtmlDocument($pageStr);
            $pagArrow = $response->find('table a b');
            if($pagArrow && is_array($pagArrow)) {
                $pagArrow = $pagArrow && count($pagArrow) > 1 ? $pagArrow[1] : $pagArrow[0];
                $pagArrowText = $pagArrow ? $pagArrow->innertext : "";
            }else {
                $pagArrow = '1';
                $pagArrowText = '1';
            }

            $this->productParse($response, $cat);
        }
    }

    private function productParse($response, $cat) {
        $fields = $this->setFieldsFromDom($response);
        $table = $response->find('table#MyTable', 0);
        $rowTable = $table ?  $table->find('#TheBody tr') : "";
        if($rowTable){
            foreach ($rowTable as $row) {
                $name = $row ? $row->find('td a', 0)->innertext : "";

                $fieldsProd = $this->setFieldValue($fields, $row);

                $prodArr = [
                    "title" => $name,
                    "slug" => "",
                    "field" => json_encode($fieldsProd, JSON_UNESCAPED_UNICODE),
                    "price" => "",
                    "unit" => null,
                    "sklad_id" => $this->skladId,
                    "category_id" => $cat->id
                ];

                $prod = ParseProduct::where([
                    ['sklad_id', $this->skladId],
                    ['title', $name],
                    ["category_id", $cat->id],
                    ["field", json_encode($fieldsProd, JSON_UNESCAPED_UNICODE)]
                ])->first();
//                Log::info("Metallotorg:: prodArr - ".json_encode($fieldsProd, JSON_UNESCAPED_UNICODE)." cat - ".$cat->title);
                if (!$prod && $prodArr) {
                    ParseProduct::insert($prodArr);
                }
            }
        }
        unset($cat->hasChildren);
        $cat->fields = json_encode($fields, JSON_UNESCAPED_UNICODE);
        $cat->status = 1;
        $cat->save();
    }

    private function setFieldsFromDom($response){
        $thead = $response->find('#MyTable thead th');
        $field = [];
        if(!empty($thead)) {
            foreach ($thead as $th) {
                $text = $th->innertext;
                $text = str_replace(array("<br/>", "<br />"), "", $text);
                $text = trim($text);
                if(strripos($text, "Наим") === false) {
                        $field[] = $text;
                }
            }
        }
        return $field;
    }

    private function setFieldValue($fields, $row) {
        $fieldsProd = [];
        if($fields && $row) {
            for ($i = 0; $i < count($fields) - 1; $i++) {
                $title = $fields[$i];
                $fieldVal = $row->find('td', $i + 1)->innertext;
                $fieldsProd[$title] = $fieldVal;
            }
        }
        return $fieldsProd;
    }

    private function getPage($url, $post = 0) {
        $curl = curl_init();

        curl_setopt_array($curl, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 0,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $post,
        ));

        $response = curl_exec($curl);

        curl_close($curl);

        return $response;
    }

    private function getLocationCode($sklad) {
        if(!empty($sklad->title)) {
            if($this->isSkladContainLocation($sklad, 'Оренбург')) {
                return "orenboyrg";
            }
            if($this->isSkladContainLocation($sklad, 'Белгород')) {
                return "belgorod_";
            }
            if($this->isSkladContainLocation($sklad, 'Брянск')) {
                return "bryansk";
            }
            if($this->isSkladContainLocation($sklad, 'Владикавказ')) {
                return "vladikavkaz";
            }
            if($this->isSkladContainLocation($sklad, 'Владимир')) {
                return "vladimir";
            }
            if($this->isSkladContainLocation($sklad, 'Волгоград')) {
                return "gvolgograd";
            }
            if($this->isSkladContainLocation($sklad, 'Вологда')) {
                return "vologda";
            }
            if($this->isSkladContainLocation($sklad, 'Воронеж')) {
                return "voronezh";
            }
            if($this->isSkladContainLocation($sklad, 'Ижевск')) {
                return 'izhevsk';
            }
            if($this->isSkladContainLocation($sklad, 'Казань')) {
                return "kazani";
            }
            if($this->isSkladContainLocation($sklad, 'Калуга')) {
                return "kaluga";
            }
            if($this->isSkladContainLocation($sklad, 'Краснодар')) {
                return "krasnodar";
            }
            if($this->isSkladContainLocation($sklad, 'Краснодар-север')) {
                return "titarovka";
            }
            if($this->isSkladContainLocation($sklad, 'Курск')) {
                return "koyrsk";
            }
            if($this->isSkladContainLocation($sklad, 'Липецк')) {
                return "lipetsk";
            }
            if($this->isSkladContainLocation($sklad, 'Лобня (Москва)')) {
                return "lobnay";
            }
            if($this->isSkladContainLocation($sklad, 'Лобня')) {
                return "lobnay";
            }
            if($this->isSkladContainLocation($sklad, 'Лобня(Москва)')) {
                return "lobnay";
            }
            if($this->isSkladContainLocation($sklad, 'Махачкала')) {
                return "maxachkala";
            }
            if($this->isSkladContainLocation($sklad, 'Москва')) {
                return "moscow";
            }
            if($this->isSkladContainLocation($sklad, 'Набережные Челны')) {
                return "57";
            }
            if($this->isSkladContainLocation($sklad, 'Ростов-на-Дону')) {
                return "naberezhni_chelni";
            }
            if($this->isSkladContainLocation($sklad, 'Назрань')) {
                return "nazran";
            }
            if($this->isSkladContainLocation($sklad, 'Нальчик')) {
                return "nalchik";
            }
            if($this->isSkladContainLocation($sklad, 'Нижний Новгород')) {
                return "nizhni-novgorod";
            }
            if($this->isSkladContainLocation($sklad, 'Новосибирск')) {
                return "novosibirs";
            }
            if($this->isSkladContainLocation($sklad, 'Новочеркасск')) {
                return "novocherka";
            }
            if($this->isSkladContainLocation($sklad, 'Орел')) {
                return "orel";
            }
            if($this->isSkladContainLocation($sklad, 'Пенза')) {
                return "penza";
            }
            if($this->isSkladContainLocation($sklad, 'Пятигорск')) {
                return "pyatigor";
            }
            if($this->isSkladContainLocation($sklad, 'Ростов-на-Дону')) {
                return "rostov-on-don";
            }
            if($this->isSkladContainLocation($sklad, 'Рязань')) {
                return "ryazani";
            }
            if($this->isSkladContainLocation($sklad, 'Самара')) {
                return "samara";
            }
            if($this->isSkladContainLocation($sklad, 'Санкт-Петербург')) {
                return "saint-petersburg";
            }
            if($this->isSkladContainLocation($sklad, 'Саранск')) {
                return "saransk";
            }
            if($this->isSkladContainLocation($sklad, 'Саратов')) {
                return "saratov";
            }
            if($this->isSkladContainLocation($sklad, 'Ставрополь')) {
                return "stavropoli";
            }
            if($this->isSkladContainLocation($sklad, 'Старый Оскол')) {
                return "oskol";
            }
            if($this->isSkladContainLocation($sklad, 'Сызрань')) {
                return "syzran";
            }
            if($this->isSkladContainLocation($sklad, 'Тверь')) {
                return "tver";
            }
            if($this->isSkladContainLocation($sklad, 'Тула')) {
                return "tula";
            }
            if($this->isSkladContainLocation($sklad, 'Ульяновск')) {
                return "ulyanovsk";
            }
            if($this->isSkladContainLocation($sklad, 'Уфа')) {
                return "oyfa";
            }
            if($this->isSkladContainLocation($sklad, 'Чебоксары')) {
                return "cheboksary";
            }
            if($this->isSkladContainLocation($sklad, 'Челябинск')) {
                return "chelyabinsk";
            }
            if($this->isSkladContainLocation($sklad, 'Череповец')) {
                return "cherep";
            }
            if($this->isSkladContainLocation($sklad, 'Чехов (Москва)')) {
                return "chexov";
            }
            if($this->isSkladContainLocation($sklad, 'Чехов')) {
                return "chexov";
            }
            if($this->isSkladContainLocation($sklad, 'Электроугли')) {
                return "electro-ugli";
            }
            if($this->isSkladContainLocation($sklad, 'Ярославль')) {
                return "yaroslavl";
            }

            return "all";
        }

    }

    private function isSkladContainLocation($sklad, $location) {
        if(!empty($sklad->title) && !empty($sklad->address)) {
            return strripos($sklad->title, $location) !== false || strripos($sklad->address, $location) !== false;
        } else if (!empty($sklad->address_office)) {
            return strripos($sklad->address_office, $location) !== false;
        }
    }

    private function removeAll($skladId) {
        ParseProduct::removeAllProducts($skladId);
        ParserCategory::removeAllCategory($skladId);
    }

    public function refreshCategories() {
        Log::info("===============================refreshCategories=================================");
        $this->removeAll($this->skladId);
        $this->parsing($this->skladId);
    }

}
