<?php

namespace App\Models\Parser;

use App\Models\Alert;
use App\Models\ParseProduct;
use App\Models\ParserCategory;
use App\Models\ProductFieldReplace;
use App\Models\Sklad;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Log;
use simplehtmldom\HtmlDocument;

class SkatUral extends Model
{
    use HasFactory;

    private $CATALOGURL = 'https://www.skatural.ru/catalog/';
    private $SITE = 'https://www.skatural.ru/';
    protected $skladId;

    public function __construct($skladId)
    {
        $this->skladId = $skladId;
    }

    public function parsing($skladId = 0) {
        if($skladId) {
            $sklad = Sklad::find($skladId);
            if($sklad) {
                $alertId = Alert::startParsing($skladId);
                $this->setCategoriesFromDom();
                $this->setProducts();
                Alert::stopParsing($alertId);
            }
        }
    }

    private function setCategoriesFromDom(){
        $response = $this->getPage($this->CATALOGURL);
        $response = new HtmlDocument($response);
        $htmlSidebar = $response->find('.leftmenu__inn .leftmenu__item');
        if(!empty($htmlSidebar)){
            foreach ($htmlSidebar as $item){
                $link = $item->find('a', 0);
                $title = $item->find('span', 0)->plaintext;
                $numb = $item->find('span em', 0)->plaintext;
                $title = str_replace($numb, "", $title);
                if(!empty($link)) {
                    $resultArr = [
                        "title" => $title,
                        "url" => $link->attr['href'],
                        "parent_id" => null,
                        "sklad_id" => $this->skladId,
                        "status" => 0,
                    ];
                    $parentid = ParserCategory::insertGetId($resultArr);
                    $domCat = $item->find('ul.leftmenu__subul li a');
                    foreach ($domCat as $dom){
                        $cresultArr = [
                            "title" => $dom->plaintext,
                            "url" => $dom->attr['href'],
                            "parent_id" => $parentid,
                            "sklad_id" => $this->skladId,
                            "status" => 0,
                        ];
                        ParserCategory::insert($cresultArr);
                    }
                }
            }
        }
    }

    private function setProducts($withCheckDB = 1) {
        $category = ParserCategory::where([
            ['sklad_id', $this->skladId],
            ['status', 0]
        ])->get();
        $category = ParserCategory::addHasChildrenProp($category, $this->skladId);
        if($category) {
            foreach ($category as $cat) {
                if(!empty($cat->url) && $cat->hasChildren == false) {
                    $pageStr = $this->getPage($cat->url);
                    $response = new HtmlDocument($pageStr);
                    $fields = $this->setFieldsFromDom($response);

                    $rowTable = $response->find('table#subcattable tbody tr');
                    foreach ($rowTable as $row) {
                        $name = $row->find('a', 0)->plaintext;
                        $link = $row->find('a', 0)->attr['href'];
                        $link = !empty($link) ? str_replace($this->SITE, "/", $link) : "";

                        $fieldsProd = $this->setFieldValue($fields, $row);


                        $prodArr = [
                            "title" => $name,
                            "slug" => $link,
                            "field" => json_encode($fieldsProd, JSON_UNESCAPED_UNICODE),
                            "price" => "",
                            "unit" => null,
                            "sklad_id" => $this->skladId,
                            "category_id" => $cat->id
                        ];

                        if ($withCheckDB == 1) {
                            $prod = ParseProduct::where([
                                ['sklad_id', $this->skladId],
                                ['title', $name],
                                ["category_id", $cat->id],
                                ["field", json_encode($fieldsProd, JSON_UNESCAPED_UNICODE)]
                            ])->first();
                            if (!$prod && $prodArr) {
                                ParseProduct::insert($prodArr);
                            }
                        } else {
                            if ($prodArr) {
                                ParseProduct::insert($prodArr);
                            }
                        }
                    }
                    unset($cat->hasChildren);
                    $cat->fields = json_encode($fields, JSON_UNESCAPED_UNICODE);
                    $cat->status = 1;
                    $cat->save();
                }
            }
        }
    }

    private function setFieldsFromDom($response) {
        $thead = $response->find('table#subcattable thead th');
        $field = [];
        if(!empty($thead)) {
            foreach ($thead as $th) {
                if(strripos($th->plaintext, "Наим") === false) {
                    if(strripos($th->plaintext, "Наличие") !== false) {
                        $unit = $th->find('span', 0);
                        $title = !empty($unit) ? str_replace($unit->plaintext, "", $th->plaintext) : $th->plaintext;
//                        $title = $this->replaceField($title);
                        $field[] = $title;
                    } else {
                        $field[] = $th->plaintext;
//                        $field[] = $this->replaceField($title);
                    }
                }
            }
        }

        return $field;
    }

    private function replaceField($title) {
        $replace = ProductFieldReplace::where([
            ['title_old', $title]
        ])->first();
        if(!empty($replace))
            $title = $replace->title;

        return $title;
    }

    private function getPage($url) {
        $post = 0;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url); // отправляем на
        curl_setopt($ch, CURLOPT_HEADER, true); // пустые заголовки
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); // возвратить то что вернул сервер
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 3); // следовать за редиректами
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);// таймаут4
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_ENCODING ,"");
        curl_setopt($ch, CURLOPT_POST, $post!==0 ); // использовать данные в post
//        curl_setopt($ch, CURLOPT_HTTPHEADER, array("Cookie: locationNewThree=".$location.";")); //отправка куки с кодом локации
        if($post)
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        $data = curl_exec($ch);
        curl_close($ch);

        return $data;
    }

    private function removeAll($skladId) {
        ParseProduct::removeAllProducts($skladId);
        ParserCategory::removeAllCategory($skladId);
    }

    public function refreshCategories() {
        Log::info("===============================refreshCategories=================================");
        $alertId = Alert::startParsing($this->skladId);
        $this->removeAll($this->skladId);
        $this->parsing($this->skladId);
        Alert::stopParsing($alertId);
    }

    private function setFieldValue($fields, $row) {
        $fieldsProd = [];
        if($fields && $row) {
            for ($i = 0; $i < count($fields); $i++) {
                $title = $fields[$i];
                $fieldVal = $row->find('td', $i + 1)->plaintext;
                $fieldsProd[$title] = $fieldVal;
            }
        }
        return $fieldsProd;
    }


}
