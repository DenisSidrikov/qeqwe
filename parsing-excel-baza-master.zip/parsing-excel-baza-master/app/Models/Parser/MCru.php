<?php

namespace App\Models\Parser;

use App\Jobs\ProcessParse;
use App\Models\Alert;
use App\Models\ParseProduct;
use App\Models\ParserCategory;
use App\Models\ProductFieldReplace;
use App\Models\Sklad;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Log;
use simplehtmldom;
use simplehtmldom\HtmlWeb;

class MCru extends Model
{
    use HasFactory;

    public function parsing($skladId = 0) {

        if($skladId) {
            $sklad = Sklad::find($skladId);

            if($sklad) {
                $site = $sklad->site;
                $alertId = Alert::startParsing($skladId);
                $resultArr = $this->getCategoriesFromSite($sklad);
                if (!empty($resultArr)) {
                    ParserCategory::insert($resultArr);
                }
                $this->setCategoriesAndProducts($site, $skladId);
                if($this->isNullStatusSklad($skladId)) {
                    $this->setCategoriesAndProducts($site, $skladId, 1, 1);
                }
                Alert::stopParsing($alertId);
            }
        }
    }

    public function getCategoriesFromSite($sklad) {
        $response = simplexml_load_file('https://mc.ru/sitemap.prod1.xml');
        $resultArr = $this->getCategoryLinksFromSitemap($response, $sklad);
        $response = simplexml_load_file( 'https://mc.ru/sitemap.prod2.xml');
        $resultArr = array_merge($resultArr, $this->getCategoryLinksFromSitemap($response, $sklad));
        $response = simplexml_load_file( 'https://mc.ru/sitemap.prod3.xml');
        $resultArr = array_merge($resultArr, $this->getCategoryLinksFromSitemap($response, $sklad));
//        Log::info('getCategoriesFromSite OK');
        return $resultArr;
    }

    public function getCategoryLinksFromSitemap($response, $sklad) {
        $result = [];
        $resultArr = [];
        $site = $sklad->site;
        $region = strripos($site, 'multiprice') !== false ? explode('/', $site) : [];
        $region =  end( $region);
        $region = $this->replaceRegionForSitemap($region);
        $arr = [];
        foreach ($response as $item) {
            $itemstr = $item->loc;
            $strAr = explode('/', $item->loc);
            $strout = "";
            if(empty($region)) {
                if (count($strAr) >= 5) {
                    for ($i = 3; $i < 5; $i++) {
                        $strout .= '/' . $strAr[$i];
                    }

                    if (!in_array($strout, $result) && strpos($strout, '/region/') === false && strpos($strout, '/products/') === false) {
                        $result[] = $strout;
                        $resultArr[] = [
                            "title" => "",
                            "url" => $strout,
                            "parent_id" => null,
                            "sklad_id" => $sklad->id,
                            "status" => 0,
                        ];
                    }
                }
            } else {
                if(strripos(trim($itemstr), $region) !== false) {
                    if (count($strAr) >= 6) {
                        for ($i = 5; $i < 7; $i++) {
                            $strout .= '/' . $strAr[$i];
                        }
                        if (!in_array($strout, $result) && strpos($strout, '/region/') === false && strpos($strout, '/products/') === false) {

                            $result[] = $strout;
                            $resultArr[] = [
                                "title" => "",
                                "url" => $strout,
                                "parent_id" => null,
                                "sklad_id" => $sklad->id,
                                "status" => 0,
                            ];
                        }
                    }
                }
            }
        }
        return $resultArr;
    }

    public function setCategoriesFromSite($resultArr) {
        if(!empty($resultArr)) {
            foreach ($resultArr as $res) {
                $resp = ParserCategory::where([
                    ['url', $res['url']],
                    ['sklad_id', $res['sklad_id']]
                ])->first();
//                Log::info('setCategoriesFromSite - '.$res['url']);
                if (empty($resp)) {
                    $resultArr = [
                        "title" => "",
                        "url" => $res['url'],
                        "parent_id" => null,
                        "sklad_id" => $res['sklad_id'],
                        "status" => 0,
                    ];
                    ParserCategory::insert($resultArr);
                }
            }
        }
    }

    public function replaceRegionForSitemap($region) {
        if($region == 'speterburg') {
            $region = 'spb';
        }
        return $region;
    }

    public function setCategoryLinksWithCheck($response, $skladId) {
        $result = [];
        $resultArr = [];
        $arr = [];
        foreach ($response as $item) {
            //разбиваем урл по слешу /
            $strAr = explode('/', $item->loc);
            $strout = "";
            //если урл разбился больше чем на 5 частей
            if(count($strAr) >= 5) {
                //если в урл входит региональность, то собираем ссылку с 3 по 6 элементы
                for ($i = 3; $i < 5; $i++) {
                    $strout .= '/' . $strAr[$i];
                }

                if(!in_array($strout, $result) && strpos($strout, '/region/') === false && strpos($strout, '/products/') === false) {
                    $resp = ParserCategory::where('url', $strout)->first();
                    $result[] = $strout;
                    if(empty($resp)) {
                        $resultArr = [
                            "title" => "",
                            "url" => $strout,
                            "parent_id" => null,
                            "sklad_id" => $skladId,
                            "status" => 0,
                        ];
                        if (!empty($strout)) {
                            ParserCategory::insert($resultArr);
                        }
                    }

                }
            }
        }

        return $resultArr;
    }

    public function setCategoriesAndProducts($site, $skladId, $withCheck = 0, $withStatus = 1) {
        $isAddingNewCat = 0;
        if($withStatus) {
            $allCategories = ParserCategory::where([
                ["status", 0],
                ["sklad_id", $skladId]
            ])->get();
        } else {
            $allCategories = ParserCategory::where([
                ["sklad_id", $skladId]
            ])->get();
        }


        if(strripos($site, 'multiprice') !== false) {
            $site = str_replace('multiprice', 'region', $site);
        }
        if(!empty($allCategories)) {
            foreach ($allCategories as $cat) {
                if ($cat->url) {
                    $htmlDom = ParserCategory::request($site . $cat->url);
                    $isAddingNewCat = $this->setCategoriesFromBreadcrumps($cat, $htmlDom, $skladId);
                    Log::info("setCategoriesAndProducts - ".$cat->url." --- - isAddingNewCat - ".$isAddingNewCat);
                    if(!empty($htmlDom)) {
//                        try{
                            $pageCount = $this->paginationCount($htmlDom, $site, $cat->url);
                            if ($pageCount) {
                                $this->setProductWithPaginate($skladId, $cat, $site, $pageCount, $withCheck);
                            } else {
                                $this->setProducts($htmlDom, $skladId, $cat, $withCheck);
                            }
//                        } catch (\Exception $e) {
//                            Log::info("Error - ".$e->getMessage());
//                        }
                    }
                }
                sleep(1);
            }
        }

        if($isAddingNewCat) {
            $this->setCategoriesAndProducts($site, $skladId);
        }

    }

    private function setProductWithPaginate($skladId, $cat, $site, $pageCount, $withCheck) {
        for ($i = 1; $i <= $pageCount; $i++) {
            Log::info("setProductWithPaginate - ".$cat->url . "/PageN/" . $i);
            $htmlDom = ParserCategory::request($site . $cat->url . "/PageN/" . $i);
//            if(!empty($htmlDom)) {
            $this->setProducts($htmlDom, $skladId, $cat, $withCheck);
//            }
            sleep(1);
        }
    }

    private function paginationCount($htmlDom, $site, $url, $pageIteration = 0) {
        if(!empty($htmlDom)) {
            $htmlPages = $htmlDom->find('.catalogPaginator > ul > li');
            $pageCount = (!empty($htmlPages) && count($htmlPages)) ? count($htmlPages) : 0;
            if($pageCount >= 17) {
//                Log::info("paginationCount more 17 on page - ".$site . $url . "/PageN/" . $pageIteration);
                $pageIteration = $pageIteration + $pageCount;
                $htmlDom = ParserCategory::request($site . $url . "/PageN/" . $pageIteration);
                $pageCount = $this->paginationCount($htmlDom, $site, $url, $pageIteration);
                return $pageCount ?? 0;
            }
            $pageCount = $pageIteration ? $pageCount + $pageIteration - 2 : $pageCount; // li кнопка << и li кнопка 17 на второй странице, которая уже посчитана
//            Log::info("paginationCount 3  - ".$pageCount);
        }
        return $pageCount ?? 0;
    }

    public function setCategoriesFromBreadcrumps($cat, $htmlDom, $skladId) {
        $wasRecursion = 0;
        if(!empty($htmlDom)) {
            $htmlDomLink = $htmlDom->find('.UrlSpeed span a');
            if (!empty($htmlDomLink)) {

                $parentLink = $this->getLastBreadCrumpLink($htmlDomLink);
//                Log::info("parentLink from Breadcrump - ".$parentLink);
                if (!empty($parentLink)) {
                    $parent = ParserCategory::where([
                        ['url', $parentLink],
                        ['sklad_id', $skladId]
                    ])->first();
                    if ($parent) {
                        $cat->parent_id = $parent->id;
                        $cat->save();
                    } else {
                        $resultArr = [
                            "title" => "",
                            "url" => $parentLink,
                            "parent_id" => null,
                            "sklad_id" => $skladId,
                            "status" => 0,
                        ];
                        $ids = ParserCategory::insertGetId($resultArr);
                        $cat->parent_id = $ids;
                        $cat->save();
                        $wasRecursion = 1;
                    }
                }
            }

            $arrHead = $this->parseCategoryTitle($htmlDom);
//            Log::info("CategoryTitle - ".$arrHead." urr - ".$cat->url);
            if(!empty($arrHead)) {
                $cat->title = $arrHead;
                $cat->status = 1;

                $cat->save();
            } else {
                Log::info($cat->url." - head MCRU");
            }
        } else {
            Log::info($cat->url." - not exist MCRU");
        }

        return $wasRecursion;
    }

    private function getLastBreadCrumpLink($htmlDomLink) {
        if(!empty($htmlDomLink)) {
            $arr = [];
            foreach ($htmlDomLink as $html) {
                if (strpos($html->attr['href'], '/products') === false && $html->attr['href'] != '/') {
                    $htmlhref = $html->attr['href'];
                    if (strpos($htmlhref, '/region') !== false) {
                        $strAr = explode('/', $htmlhref);
                        $strout = "";
                        if (count($strAr) >= 3) {
                            for ($i = 3; $i <= 4; $i++) {
                                $strout .= '/' . $strAr[$i];
                            }
                        }
                        $htmlhref = $strout;
                    }
                    $arr[] = $htmlhref;
                }
            }

            $parentLink = end($arr);

            return $parentLink;

        } else {
            return "";
        }


    }

    public function parseCategoryTitle($htmlDom) {
        $arrHead = '';
        $htmlDomHeader = $htmlDom->find('.HeaderBlock h1');
        if(!empty($htmlDomHeader)) {
            foreach ($htmlDomHeader as $html) {
                $arrHead = $html->plaintext;
                $arrHead = !empty($arrHead) ? str_replace(' в Москве', '', $arrHead) : "";
                $arrHead = !empty($arrHead) ? str_replace(' в Санкт-Петербурге', '', $arrHead) : "";
                $arrHead = !empty($arrHead) ? str_replace(' в Нижнем Новгороде', '', $arrHead) : "";
                $arrHead = !empty($arrHead) ? str_replace(' в Самаре', '', $arrHead) : "";
                $arrHead = !empty($arrHead) ? str_replace(' в Пензе', '', $arrHead) : "";
                $arrHead = !empty($arrHead) ? str_replace(' в Балаково', '', $arrHead) : "";
                $arrHead = !empty($arrHead) ? str_replace(' в г. Чебоксары', '', $arrHead) : "";
                $arrHead = !empty($arrHead) ? str_replace(' в Брянске', '', $arrHead) : "";
                $arrHead = !empty($arrHead) ? str_replace(' в Белгороде', '', $arrHead) : "";
                $arrHead = !empty($arrHead) ? str_replace(' в Ростове-на-Дону', '', $arrHead) : "";
                $arrHead = !empty($arrHead) ? str_replace(' в Таганроге', '', $arrHead) : "";
                $arrHead = !empty($arrHead) ? str_replace(' в Краснодаре', '', $arrHead) : "";
                $arrHead = !empty($arrHead) ? str_replace(' в Перми', '', $arrHead) : "";
                $arrHead = !empty($arrHead) ? str_replace(' в Екатеринбурге', '', $arrHead) : "";
                $arrHead = !empty($arrHead) ? str_replace(' в Челябинске', '', $arrHead) : "";
                $arrHead = !empty($arrHead) ? str_replace(' в Уфе', '', $arrHead) : "";
                $arrHead = !empty($arrHead) ? str_replace(' в Новосибирске', '', $arrHead) : "";
                $arrHead = !empty($arrHead) ? str_replace(' в Барнауле', '', $arrHead) : "";
                $arrHead = !empty($arrHead) ? str_replace(' в Хабаровске', '', $arrHead) : "";
            }
        } else {
            $htmlDomHeader = $htmlDom->find('.catalogHeader h1');
            if(!empty($htmlDomHeader)) {
                foreach ($htmlDomHeader as $html) {
                    $arrHead = $html->plaintext;
                    $arrHead = !empty($arrHead) ? str_replace(' в Москве', '', $arrHead) : "";
                    $arrHead = !empty($arrHead) ? str_replace(' в Санкт-Петербурге', '', $arrHead) : "";
                    $arrHead = !empty($arrHead) ? str_replace(' в Нижнем Новгороде', '', $arrHead) : "";
                    $arrHead = !empty($arrHead) ? str_replace(' в Самаре', '', $arrHead) : "";
                    $arrHead = !empty($arrHead) ? str_replace(' в Пензе', '', $arrHead) : "";
                    $arrHead = !empty($arrHead) ? str_replace(' в Балаково', '', $arrHead) : "";
                    $arrHead = !empty($arrHead) ? str_replace(' в г. Чебоксары', '', $arrHead) : "";
                    $arrHead = !empty($arrHead) ? str_replace(' в Брянске', '', $arrHead) : "";
                    $arrHead = !empty($arrHead) ? str_replace(' в Белгороде', '', $arrHead) : "";
                    $arrHead = !empty($arrHead) ? str_replace(' в Ростове-на-Дону', '', $arrHead) : "";
                    $arrHead = !empty($arrHead) ? str_replace(' в Таганроге', '', $arrHead) : "";
                    $arrHead = !empty($arrHead) ? str_replace(' в Краснодаре', '', $arrHead) : "";
                    $arrHead = !empty($arrHead) ? str_replace(' в Перми', '', $arrHead) : "";
                    $arrHead = !empty($arrHead) ? str_replace(' в Екатеринбурге', '', $arrHead) : "";
                    $arrHead = !empty($arrHead) ? str_replace(' в Челябинске', '', $arrHead) : "";
                    $arrHead = !empty($arrHead) ? str_replace(' в Уфе', '', $arrHead) : "";
                    $arrHead = !empty($arrHead) ? str_replace(' в Новосибирске', '', $arrHead) : "";
                    $arrHead = !empty($arrHead) ? str_replace(' в Барнауле', '', $arrHead) : "";
                    $arrHead = !empty($arrHead) ? str_replace(' в Хабаровске', '', $arrHead) : "";
                }
            }
        }
        return $arrHead;
    }

    public function reparsing($site, $skladId) {
//        $htmlDom = ParserCategory::request("https://mc.ru/region/speterburg/metalloprokat/filtry_set");
//        $categories = ParserCategory::where('sklad_id', $skladId)->first();
//        $this->setProducts($htmlDom, $skladId, $categories, 1);

        $this->setCategoriesAndProducts($site, $skladId, 1);

//        $allCategories = ParserCategory::whereNull('parent_id')->get();
//        foreach ($allCategories as $cat) {
//            if($cat->url) {
//                $htmlDom = ParserCategory::request($site.$cat->url);
//                $this->setProducts($htmlDom, $skladId, $cat, 1);
//            }
//            sleep(1);
//        }
    }

    private function setProducts($htmlDom, $skladId, $category, $withCheckDB = 0) {
//        Log::info("setProducts - ".$category->url);
//        try {
            $htmlProdTable = $htmlDom->find('.catalogTable');
            if(!empty($htmlProdTable)){
                $resultProd = [];
                //парсим шапку с характеристиками и запоминаем их и индекс цены
                $htmlProdThead = $htmlDom->find('.catalogItemsFilters > li');
                $feildsTitle = [];
                $fieldsCat = [];
                if(!empty($htmlProdThead)) {
                    $priceIndex = 1;
                    foreach ($htmlProdThead as $key=>$li) {
                        $submenu = $li->find('.submenu', 0);
                        $title = !empty($submenu) ? $submenu->plaintext : $li->plaintext;

                        if(strripos($title, 'Продукция') === false) {
                            $feildsTitle[$key] =  $title;
                            $fieldsCat[] = $title;
                        }

//                        if(strripos($title, 'Цена') !== false) {
//                            $priceIndex = $key;
//                            $feildsTitle[$key] =  'Цена';
//                            break;
//                        }
                    }
                }
                $htmlProdRow = $htmlDom->find('.catalogTable tbody tr');


                if(!empty($htmlProdRow)) {
                    foreach ($htmlProdRow as $row) {
                        $deliv = !empty($row->attr['class']) ? $row->attr['class'] : "";
                        if(strripos($deliv, 'delivery') === false || empty($row->attr['class']) || empty($deliv)) {
                            $name = $row->children(0)->plaintext;
                            $name = str_replace('→', '', $name);
                            $slug = $row->children(0)->children(1);
                            $slug = $slug ? $slug->href : "";
                            $fields = [];
                            Log::info("MCRU title - ".$name." - slug - ". $slug);
                            for ($i = 1; $i < count($feildsTitle); $i++) {
                                $fieldVal = $row->find('td', $i);// children($i);
                                if (!empty($fieldVal)) {
                                    if (iconv_strlen($fieldVal->innertext) < 3000) {
                                        $fieldVal = $fieldVal->plaintext;
                                    } else {
//                                        Log::info("fields  1000 - ".$title." - val - ". $fieldVal);
                                        if (strripos($fieldVal->innertext, 'Челябинск') !== false) {
                                            $fieldVal = 'Челябинск';
                                        }
                                    }
                                }
                                $title = $feildsTitle[$i];
                                $fields[$title] = $fieldVal;
                                Log::info("MCRU fields - ".$title." - val - ". $fieldVal);
                            }
//                            $price = $row->children($priceIndex);
//                            $price = (!empty($price) && strripos($title, 'Цена') !== false) ? $price->plaintext : 0;

                            $resultProd = [
                                "title" => $name,
                                "slug" => $slug,
                                "field" => json_encode($fields, JSON_UNESCAPED_UNICODE),
                                "price" => "",
                                "unit" => null,
                                "sklad_id" => $skladId,
                                "category_id" => $category->id
                            ];

                            if ($withCheckDB == 1) {
                                $prod = ParseProduct::where('sklad_id', $skladId)->where('title', $name)->orWhere('slug', $slug)->first();

                                if (!$prod && $resultProd) {
                                    ParseProduct::insert($resultProd);
                                }
                            } else {
                                if ($resultProd) {
                                    ParseProduct::insert($resultProd);
                                }
                            }

                            if (!empty($fieldsCat)) {
                                $category->fields = json_encode($fieldsCat, JSON_UNESCAPED_UNICODE);
                                $category->save();
                            }
                        }

                    }
                }

            }
//        } catch (\Exception $e) {
//            Log::info("MCRU Error");
//        }

    }

    public function refreshCategories($skladId) {
        Log::info("===============================MCRU refreshCategories=================================");
        $sklad = Sklad::find($skladId);
        $site = $sklad->site;
        $skladId = $sklad->id;
        $alertId = Alert::startParsing($sklad->id);
        $this->removeAll($skladId);
        $this->parsing($skladId);
//        $resultArr = $this->getCategoriesFromSite($sklad);
//        $this->setCategoriesFromSite($resultArr);
//        $this->setCategoriesAndProducts($site, $skladId, 1, 1);
        Alert::stopParsing($alertId);
    }

    private function isNullStatusSklad($skladId) {
        $count = ParserCategory::where([
            ['sklad_id', $skladId],
            ['status', 0]
        ])->count();
        return $count ? true : false;
    }

    private function removeAll($skladId) {
        ParseProduct::removeAllProducts($skladId);
        ParserCategory::removeAllCategory($skladId);
    }



}
