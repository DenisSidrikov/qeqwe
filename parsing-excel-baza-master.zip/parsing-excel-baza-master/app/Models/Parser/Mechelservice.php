<?php

namespace App\Models\Parser;

use App\Models\Alert;
use App\Models\ParseProduct;
use App\Models\ParserCategory;
use App\Models\ProductFieldReplace;
use App\Models\Sklad;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Log;
use simplehtmldom\HtmlDocument;

class Mechelservice extends Model
{
    use HasFactory;

    private $CATALOGURL = 'https://www.mechelservice.ru/catalog/';
    private $SITE = 'https://www.mechelservice.ru';
    protected $skladId;

    public function __construct($skladId)
    {
        $this->skladId = $skladId;
    }

    public function parsing($skladId = 0) {

        if($skladId) {
            $sklad = Sklad::find($skladId);

            if($sklad) {
                $alertId = Alert::startParsing($skladId);
                $domStr = $this->getCatalogPage($sklad);
                $this->setCategoriesFromDom($domStr);
                $this->setProducts();
                Alert::stopParsing($alertId);
            }
        }
    }

    private function getCatalogPage($sklad) {
        $locationCode = $this->getLocationCode($sklad);
        Log::info("Mechel - location code - ".$locationCode);
        $data = $this->getPage($this->CATALOGURL, $locationCode);
        return $data;
    }

    private function setCategoriesFromDom($domStr){
        $response = new HtmlDocument($domStr);
        $htmlDomLink = $response->find('.sections>.row>.col-md-2.col-xs-2 a');
        $parentHtmlDomLink = $response->find('.sections>.row>.col-md-2.col-xs-2');
        $resultArr = [];


        foreach ($parentHtmlDomLink as $parentdom) {
            $parent = $parentdom->find('p', 0);
            $parresultArr = [
                "title" => $parent->plaintext,
                "url" => $this->CATALOGURL,
                "parent_id" => null,
                "sklad_id" => $this->skladId,
                "status" => 1,
            ];
            $parentid = ParserCategory::insertGetId($parresultArr);
            $domCat = $parentdom->find('a');
            foreach ($domCat as $dom){
                $resultArr = [
                    "title" => $dom->plaintext,
                    "url" => $dom->attr['href'],
                    "parent_id" => $parentid,
                    "sklad_id" => $this->skladId,
                    "status" => 0,
                ];
                ParserCategory::insertGetId($resultArr);
            }
        }

    }

    private function setProducts($withCheckDB = 1)
    {
        $sklad = Sklad::find($this->skladId);
        $locationCode = $this->getLocationCode($sklad);
        $categories = ParserCategory::whereNotNull('parent_id')->where('sklad_id', $this->skladId)->get();
        Log::info("========================Mechel=============================");
        if ($categories) {
            foreach ($categories as $cat) {
                Log::info("Mechel - ".$cat->title." - ". $cat->url);
                $pageStr = $this->getPage($this->SITE . $cat->url, $locationCode);
                $response = new HtmlDocument($pageStr);
                $fields = $this->setFieldsFromDom($response);

                $paginateBlock = $response->find('.catalog-section p font', 1);
                if($paginateBlock) {
                    $this->parseProduct($response, $cat, $fields, $withCheckDB);
                    $paginate = $paginateBlock->find('a');
                    $pageArr = [];
                    foreach ($paginate as $pg) {
                        $str = $pg->innertext;
                        if(strripos($str, "След") === false && strripos($str, "Конец") === false) {
                            $pageArr[] = $str;
                        }
                    }
                    $maxPage = $pageArr ? end($pageArr) : 5;
                    Log::info("Mechel - ".$maxPage);
                    $pageCounter = 1;
                    while ($pageCounter < $maxPage) {
                        $pageCounter++;
                        Log::info("Mechel - ".$cat->title." - ". $cat->url."?PAGEN_2=".$pageCounter);
                        $pageStr = $this->getPage($this->SITE . $cat->url."?PAGEN_2=".$pageCounter, $locationCode);
                        $response = new HtmlDocument($pageStr);
                        $this->parseProduct($response, $cat, $fields, $withCheckDB);
                    }

                } else {
                    $this->parseProduct($response, $cat, $fields, $withCheckDB);
                }

                $cat->fields = json_encode($fields, JSON_UNESCAPED_UNICODE);
                $cat->status = 1;
                $cat->save();

            }
//            dd(implode(',', $fields));
        }

    }

    private function parseProduct($response, $cat, $fields, $withCheckDB) {
        $prodDom = $response->find('table.table-catalog tr');
        if($prodDom) {
            foreach ($prodDom as $prod) {
                $fieldsProd = [];
                $name = $this->getProdTitle($prod, $cat);
                for ($i = 1; $i <= count($fields); $i++) {
                    $title = $fields[$i];
                    $fieldVal = $this->getProdFieldValue($prod, $i);
                    if(strripos($title, "Наличие") !== false) {
                        $availabilityDom = $prod->find('span', 0);
                        $fieldVal = $availabilityDom ? $availabilityDom->getAttribute('title') : " - ";
                    }
//                            Log::info("Mechel field - ".$i." - ". $fields[$i]. " - ". $fieldVal);

                    $fieldsProd[$title] = $fieldVal;
                }
                $prodArr = [
                    "title" => $name,
                    "slug" => "",
                    "field" => json_encode($fieldsProd, JSON_UNESCAPED_UNICODE),
                    "price" => "",
                    "unit" => null,
                    "sklad_id" => $this->skladId,
                    "category_id" => $cat->id
                ];
//                Log::info("Mechel Product - ".$name);
                if($withCheckDB == 1) {
                    $prod = ParseProduct::where([
                        ['sklad_id', $this->skladId],
                        ['title', $name],
                        ["category_id", $cat->id],
                        ["field", json_encode($fieldsProd, JSON_UNESCAPED_UNICODE)]
                    ])->first();
//                            Log::info("Product1 - ".$prod->title);
                    if(!$prod && $prodArr) {
                        ParseProduct::insert($prodArr);
                    }
                } else {
                    if($prodArr) {
                        ParseProduct::insert($prodArr);
                    }
                }

            }
        }

        $cat->fields = json_encode($fields, JSON_UNESCAPED_UNICODE);
        $cat->status = 1;
        $cat->save();
    }

    private function setFieldsFromDom($response) {
        $fields = [];
        $fieldDom = $response->find('.table-catalog thead td');
        if(count($fieldDom)) {
            foreach ($fieldDom as $key=>$fd) {
                $spantitle = $fd->find('span', 0);
                $fieldTitle = $spantitle ? $spantitle->plaintext : $fd->plaintext;
//                if(strripos($fieldTitle, "цена") !== false){
//                    $fieldTitle = $this->replacePrice($fieldTitle);
//                }
                $fieldTitle = str_replace(array("\r\n", "\r", "\n"), ' ', $fieldTitle);
//                $fieldTitle = $name = $this->replaceField($fieldTitle);

                if(strripos($fieldTitle, "Продукция") === false && strripos($fieldTitle, "Купить") === false) {
                    $fields[$key] = $fieldTitle;
                }
            }
        }
        return $fields;
    }

    private function getProdTitle($prod, $category) {
        $name = "";
        if($prod) {
            $mobtext = $prod->find('.catalogListProductsMobileTitle', 0);
            $mobtext = $mobtext ? $mobtext->plaintext : "";
            $name = $prod->children(0)->plaintext;
            $name = $name ? str_replace($mobtext, "", $name) : $name;
            $name = str_replace(array("\r\n", "\r", "\n"), ' ', $name);
            $name = str_replace(array(","), '', $name);
//            $name = $this->replaceField($name);
        }
        return $name;
    }

    private function replaceField($title) {
        $replace = ProductFieldReplace::where([
            ['title_old', $title]
        ])->first();
        if(!empty($replace))
            $title = $replace->title;

        return $title;
    }

    private function getProdFieldValue($prod, $i) {
        $fieldVal = $prod->children($i);
        $mobtext = $fieldVal->find('.catalogListProductsMobileTitle', 0);
        $mobtext = $mobtext ? $mobtext->plaintext : "";
        $fieldVal = !empty($fieldVal) ? $fieldVal->plaintext : "";
        $fieldVal = $fieldVal ? str_replace($mobtext, "", $fieldVal) : $fieldVal;
        return $fieldVal;
    }

    private function getLocationCode($sklad) {
        Log::info("Mechel sklad - ".$sklad->title." ".$sklad->address);
        if(!empty($sklad->title)) {
            if($this->isSkladContainLocation($sklad, 'Абакан')) {
                return "95";
            }
            if($this->isSkladContainLocation($sklad, 'Барнаул')) {
                return "01";
            }
            if($this->isSkladContainLocation($sklad, 'Бийск')) {
                return "01405";
            }
            if($this->isSkladContainLocation($sklad, 'Владивосток')) {
                return "05";
            }
            if($this->isSkladContainLocation($sklad, 'Екатеринбург')) {
                return "65";
            }
            if($this->isSkladContainLocation($sklad, 'екб')) {
                return "65";
            }
            if($this->isSkladContainLocation($sklad, 'Иркутск')) {
                return "25";
            }
            if($this->isSkladContainLocation($sklad, 'Казань')) {
                return "92";
            }
            if($this->isSkladContainLocation($sklad, 'Кемерово')) {
                return '32';
            }
            if($this->isSkladContainLocation($sklad, 'Киров')) {
                return "33";
            }
            if($this->isSkladContainLocation($sklad, 'Краснодар')) {
                return "03";
            }
            if($this->isSkladContainLocation($sklad, 'Красноярск')) {
                return "04";
            }
            if($this->isSkladContainLocation($sklad, 'Москва')) {
                return "45";
            }
            if($this->isSkladContainLocation($sklad, 'Набережные Челны')) {
                return "9243";
            }
            if($this->isSkladContainLocation($sklad, 'Нижний Новгород')) {
                return "22";
            }
            if($this->isSkladContainLocation($sklad, 'Новокузнецк')) {
                return "32431";
            }
            if($this->isSkladContainLocation($sklad, 'Новосибирск')) {
                return "50";
            }
            if($this->isSkladContainLocation($sklad, 'Омск')) {
                return "52";
            }
            if($this->isSkladContainLocation($sklad, 'Оренбург')) {
                return "53";
            }
            if($this->isSkladContainLocation($sklad, 'Пермь')) {
                return "57";
            }
            if($this->isSkladContainLocation($sklad, 'Ростов-на-Дону')) {
                return "60";
            }
            if($this->isSkladContainLocation($sklad, 'Рязань')) {
                return "61";
            }
            if($this->isSkladContainLocation($sklad, 'С-Петербург')) {
                return "40";
            }
            if($this->isSkladContainLocation($sklad, 'Санкт-Петербург')) {
                return "40";
            }
            if($this->isSkladContainLocation($sklad, 'Спб')) {
                return "40";
            }
            if($this->isSkladContainLocation($sklad, 'Самара')) {
                return "36";
            }
            if($this->isSkladContainLocation($sklad, 'Саратов')) {
                return "63";
            }
            if($this->isSkladContainLocation($sklad, 'Старый Оскол')) {
                return "1444";
            }
            if($this->isSkladContainLocation($sklad, 'Сургут')) {
                return "71136";
            }
            if($this->isSkladContainLocation($sklad, 'Сыктывкар')) {
                return "87";
            }
            if($this->isSkladContainLocation($sklad, 'Томск')) {
                return "69";
            }
            if($this->isSkladContainLocation($sklad, 'Тюмень')) {
                return "71";
            }
            if($this->isSkladContainLocation($sklad, 'Уфа')) {
                return "80";
            }
            if($this->isSkladContainLocation($sklad, 'Хабаровск')) {
                return "08";
            }
            if($this->isSkladContainLocation($sklad, 'Чебоксары')) {
                return "97";
            }
            if($this->isSkladContainLocation($sklad, 'Челябинск')) {
                return "75";
            }
            if($this->isSkladContainLocation($sklad, 'Чита')) {
                return "76";
            }

            return "45"; //Москва по дефолту
        }

    }

    private function isSkladContainLocation($sklad, $location) {
//        Log::info("Mechel location name - ".$location);
        if(!empty($sklad->title) && !empty($sklad->address)) {
            return strripos($sklad->title, $location) !== false || strripos($sklad->address, $location) !== false;
        } else if (!empty($sklad->address_office)) {
            return strripos($sklad->address_office, $location) !== false;
        }
    }

    private function getPage($url, $location) {
        $post = 0;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url); // отправляем на
        curl_setopt($ch, CURLOPT_HEADER, true); // пустые заголовки
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); // возвратить то что вернул сервер
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 3); // следовать за редиректами
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);// таймаут4
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_ENCODING ,"");
        curl_setopt($ch, CURLOPT_POST, $post!==0 ); // использовать данные в post
        curl_setopt($ch, CURLOPT_HTTPHEADER, array("Cookie: locationNewThree=".$location.";")); //отправка куки с кодом локации
        if($post)
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        $data = curl_exec($ch);
        curl_close($ch);

        return $data;
    }

    private function replacePrice($fieldTitle) {
        $fieldTitle = trim($fieldTitle);
        $fieldTitle = str_replace(array("\r\n", "\r", "\n"), ' ', $fieldTitle);
        $fieldTitle = str_replace(",", "", $fieldTitle);
        return $fieldTitle;
    }

    private function removeAll($skladId) {
        ParseProduct::removeAllProducts($skladId);
        ParserCategory::removeAllCategory($skladId);
    }

    public function refreshCategories($skladId) {
        Log::info("===============================Mechel refreshCategories=================================");
        $alertId = Alert::startParsing($skladId);
        $this->removeAll($skladId);
        $this->parsing($skladId);
        Alert::stopParsing($alertId);
    }




}
