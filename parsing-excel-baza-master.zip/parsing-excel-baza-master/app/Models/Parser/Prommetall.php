<?php

namespace App\Models\Parser;

use App\Models\Alert;
use App\Models\CategoryTitleReplace;
use App\Models\ParseProduct;
use App\Models\ParserCategory;
use App\Models\ProductFieldReplace;
use App\Models\Provider;
use App\Models\Sklad;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Log;
use simplehtmldom\HtmlDocument;

class Prommetall extends Model
{
    use HasFactory;

    private $PRICE;
    private $SITE;
    protected $skladId;

    public function __construct($skladId)
    {
        $this->skladId = $skladId;
        $this->SITE = $this->getSite();
        $this->PRICE = $this->SITE.'price';
        Log::info("===============================");
        Log::info("SITE - ". $this->SITE);
        Log::info("PRICE - ". $this->PRICE);
    }

    public function parsing() {
        if($this->skladId) {
            $skladId = $this->skladId;
            $sklad = Sklad::find($skladId);
            if($sklad) {
                $alertId = Alert::startParsing($skladId);
                $this->setCategoriesFromDom();
                $this->setProducts();
                Alert::stopParsing($alertId);
            }
        }
    }

    private function setCategoriesFromDom() {
        $response = $this->getPage($this->PRICE);
        $response = new HtmlDocument($response);
        $htmlSidebar = $response->find('.order-last a.list-group-item');
        if($htmlSidebar) {
            foreach ($htmlSidebar as $item) {
                $link = $item->attr['href'];
                $title = $item->plaintext;
                $replace = CategoryTitleReplace::where([
                    ['title_old', $title]
                ])->first();
                if(!empty($replace))
                    $title = $replace->title;

                $resultArr = [
                    "title" => $title,
                    "url" => $link,
                    "parent_id" => null,
                    "sklad_id" => $this->skladId,
                    "status" => 0,
                ];
                ParserCategory::insert($resultArr);
            }
        }
    }

    private function setProducts($withCheckDB = 1) {
        $category = ParserCategory::where([
            ['sklad_id', $this->skladId],
            ['status', 0]
        ])->get();
        if($category) {
            foreach ($category as $cat) {
                if (!empty($cat->url)) {
                    $site = $this->SITE.$cat->url;
                    $site = str_replace("//", "/", $site);
                    $pageStr = $this->getPage($site);
                    $response = new HtmlDocument($pageStr);
                    $table = $response->find('div.table-responsive table');
//                    dd($table , $site);
                    if(!empty($table)) {
                        foreach ($table as $tbl) {
                            $fields = $this->setFieldsFromDom($tbl, $cat);
                            $tbody = $tbl->find('tr');

                            foreach ($tbody as $tr) {

                                $name = $this->getFieldTitle($response, $cat);


                                $fieldsProd = $this->setFieldValue($fields, $tr);

                                $prodArr = [
                                    "title" => $name,
                                    "slug" => "",
                                    "field" => json_encode($fieldsProd, JSON_UNESCAPED_UNICODE),
                                    "price" => "",
                                    "unit" => null,
                                    "sklad_id" => $this->skladId,
                                    "category_id" => $cat->id
                                ];

                                if ($withCheckDB == 1) {
                                    $prod = ParseProduct::where([
                                        ['sklad_id', $this->skladId],
                                        ['title', $name],
                                        ["category_id", $cat->id],
                                        ["field", json_encode($fieldsProd, JSON_UNESCAPED_UNICODE)]
                                    ])->first();
                                    if (!$prod && $prodArr) {
                                        ParseProduct::insert($prodArr);
                                    }
                                } else {
                                    if ($prodArr) {
                                        ParseProduct::insert($prodArr);
                                    }
                                }
                            }
                        }
                        $cat->fields = json_encode($fields, JSON_UNESCAPED_UNICODE);
                        $cat->status = 1;
                        $cat->save();
                    }
                }
            }
        }
    }

    private function getPage($url) {
        $post = 0;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url); // отправляем на
        curl_setopt($ch, CURLOPT_HEADER, true); // пустые заголовки
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); // возвратить то что вернул сервер
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 3); // следовать за редиректами
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);// таймаут4
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_ENCODING ,"");
        curl_setopt($ch, CURLOPT_POST, $post!==0 ); // использовать данные в post
//        curl_setopt($ch, CURLOPT_HTTPHEADER, array("Cookie: locationNewThree=".$location.";")); //отправка куки с кодом локации
        if($post)
            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
        $data = curl_exec($ch);
        curl_close($ch);

        return $data;
    }

    private function removeAll($skladId) {
        ParseProduct::removeAllProducts($skladId);
        ParserCategory::removeAllCategory($skladId);
    }

    public function refreshCategories() {
        Log::info("===============================refreshCategories=================================");
        $alertId = Alert::startParsing($this->skladId);
        $this->removeAll($this->skladId);
        $this->parsing();
        Alert::stopParsing($alertId);
    }

    private function setFieldsFromDom($tbl, $cat) {
        $thead = $tbl->find('th');
        $fields = [];
        foreach ($thead as $th) {
            $title = $th->plaintext;
            $title = str_replace(array("\r\n", "\r", "\n", "</br>"), " ", $title);
//            $replace = ProductFieldReplace::where([
//                ['title_old', $title]
//            ])->first();
//            if(!empty($replace))
//                $title = $replace->title;

            $fields[] = $title;
        }
        return $fields;
    }

    private function setFieldValue(array $fields, $tr) {
        $fieldsProd = [];
        if($fields && $tr) {
            for ($i = 0; $i < count($fields); $i++) {
                $title = $fields[$i];
                $fieldVal = $tr->find('td', $i) ? $tr->find('td', $i)->plaintext : "";
                $fieldsProd[$title] = $fieldVal;
            }
        }
        return $fieldsProd;
    }

    private function getSite() {
        $sklad = Sklad::where('id', $this->skladId)->first();
        return $sklad ? $sklad->site : "https://www.pkp96.ru/";
    }

    private function getFieldTitle(HtmlDocument $response, $cat) {
        $name = $response->find('h1', 0) ? $response->find('h1', 0)->plaintext : "";
        $name = str_replace("Екатеринбург", "", $name);
        $name = str_replace("Омск", "", $name);
        return $name;
    }


}
