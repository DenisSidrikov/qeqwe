<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Log;

class CustomCategory extends Model
{
    use HasFactory;

    public static function setCategory($id, $title, $categoryTitle, $oldTitle, $categories) {
        if($title && $categoryTitle) {
            if(empty($categories)) {
                $categories = [];
                $catFull = ParserCategory::where("id", $id)->first();
                $skladId = $catFull ? $catFull->sklad_id : "";
                $sklad = Sklad::where('id', $skladId)->first();
                $categories[] = $sklad ? $sklad->title : "";
            }
            $oldTitle = trim($oldTitle);
            $categories[] = $categoryTitle;
            $categories = implode("|", $categories);
            $categories = str_replace(" ", "", $categories);
            $cat = CustomCategory::where([
                ["category_path", $categories],
                ["custom_category", $oldTitle],
            ])->first();
            if($cat) {
                $cat->category_path = $categories;
                $cat->custom_category = $title;
                $cat->save();
                return json_encode(200);
            } else {
                CustomCategory::insert([
                    "category_path" => $categories,
                    "custom_category" => $title
                ]);
                return json_encode(200);
            }
        }
        return json_encode(500);
    }

    public static function getCustomCategoryById($id, $sklad) {
        $chain = self::getCategoryChildChain($id);
        $category = ParserCategory::where("id", $id)->first();
        $customCat = self::getCustomLastCategory($category, $chain, $sklad);
        return !empty($customCat) ? $customCat : "";
    }

    public static function getCustomCategory($categories, $breadcrump, $sklad){
        $catPath = [];
        if($categories){
            if(!empty($breadcrump)) {
                foreach ($breadcrump as $bc) {
                    $catPath[] = $bc['title'];
                }
            } else {
                $catPath[] = $sklad->title;
            }
            foreach ($categories as $cat) {
                $catPathStr = implode("|", $catPath);
                $catPathStr = $catPathStr."|".$cat->title;
                $catPathStr = str_replace(" ", "", $catPathStr);
                $custom = CustomCategory::where("category_path", $catPathStr)->first();
                if ($custom) {
                    $cat->custom_category = $custom->custom_category;
                }
            }
        }
        return $categories;
    }

    public static function getCustomLastCategory($category, $breadcrump, $sklad){
        $catPath = [];
        $customCategory = "";
        if($category){
            if(!empty($breadcrump) && count($breadcrump) > 1) {
                foreach ($breadcrump as $bc) {
                    $catPath[] = $bc['title'];
                }
            } else {
                $catPath[] = $sklad->title;
                $catPath[] = $category->title;
            }

            $catPathStr = implode("|", $catPath);
            $catPathStr = str_replace(" ", "", $catPathStr);
            $custom = CustomCategory::where("category_path", $catPathStr)->first();
            if ($custom) {
                $customCategory = $custom->custom_category;
            }
        }
        return $customCategory;
    }

    public static function getCategoryChildChain($id, $chain_ch = []) {
        $chain = ParserCategory::where('id', $id)->select('id', 'title', 'parent_id', 'url')->first();
        if($chain) {
            $chain = $chain->toArray();
            array_unshift($chain_ch, [
                'parent_id' => $chain['parent_id'],
                'title' => $chain['title'],
//                'url' => $chain['url'],
                'id' => $id
            ]);
        }
        if(!empty($chain['parent_id'])) {
            return CustomCategory::getCategoryChildChain($chain['parent_id'], $chain_ch);
        }
        return $chain_ch;
    }

}
