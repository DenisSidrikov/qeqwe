<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Alert extends Model
{
    use HasFactory;

    public static function startParsing($skladId) {
        $alertId = Alert::insertGetId([
            "sklad_id" => $skladId,
            "status" => 102,
            "status_string" => "Идет процесс парсинга"
        ]);

        return $alertId;
    }

    public static function stopParsing($alertId) {
        $alert = Alert::where('id', $alertId)->first();
        $alert->status = 200;
        $alert->status_string = "Данные записаны в базу";
        $alert->save();
    }

    public static function getAlertStatus($skladId) {
        $alert = Alert::where('sklad_id', $skladId)->orderBy('id', 'desc')->first();
        return $alert ?? "";
    }

    public static function getLastAlertIdBySklad($skladId) {
        $alert = Alert::where('sklad_id', $skladId)->orderBy('id', 'desc')->first();
        return $alert ? $alert->id : "";
    }

    public static function errorParsing($alertId) {
        $alert = Alert::where('id', $alertId)->first();
        $alert->status = 500;
        $alert->status_string = "Произошла ошибка";
        $alert->save();
    }


}
