<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ProductFieldReplace extends Model
{
    use HasFactory;

    public static function setField($categories, $fields, $oldFields) {
        if($categories && $fields) {
            $categories = implode("|", $categories);
            $categories = str_replace(" ", "", $categories);

            $fieldex = ProductFieldReplace::where([
                ["category_path", $categories],
                ["title_old", $oldFields]
            ])->first();
            if($fieldex) {
                if($fieldex->title_old == $fields) {
                    $fieldex->delete();
                    return json_encode(200);
                } else {
                    $fieldex->category_id = 0;
                    $fieldex->category_path = $categories;
                    $fieldex->title = $fields;
                    $fieldex->title_old = $oldFields;
                    $fieldex->save();
                    return json_encode(200);
                }

            } else {
                ProductFieldReplace::insert([
                    "category_id" => 0,
                    "category_path" => $categories,
                    "title" => $fields,
                    "title_old" => $oldFields
                ]);
                return json_encode(200);
            }
        }

        return json_encode(500);
    }

    public static function getFieldsByCategoryId($id) {
        $chain = self::getCategoryChildChain($id);
        $category = ParserCategory::where("id", $id)->first();
        $fields = self::getFields($category, $chain);
        return !empty($fields) ? $fields : "";
    }

    public static function getCategooryPath($id) {
        $chain = self::getCategoryChildChain($id);
        $catPathStr = "";
        if($chain) {
            foreach ($chain as $bc) {
                $catPath[] = $bc['title'];
            }
            $catPathStr = implode("|", $catPath);
            $catPathStr = str_replace(" ", "", $catPathStr);
        }

        return $catPathStr;
    }

    public static function getFields($cat, $breadcrump){
        $catPath = [];
        $fields = [];
        $fieldObj = [];
        if($cat && $breadcrump){
            foreach ($breadcrump as $bc) {
                $catPath[] = $bc['title'];
            }

            if($cat) {
                $catPathStr = implode("|", $catPath);
                $catPathStr = str_replace(" ", "", $catPathStr);
                $replace = ProductFieldReplace::where("category_path", $catPathStr)->get();
                if ($replace) {
                    $fields = $cat->fields ?? "";
                    $fields = $fields ? json_decode($fields) : [];
                    foreach ($fields as $fd) {
                        $fieldObj[$fd] = $fd;
                    }
                    foreach ($replace as $item) {
                        foreach ($fieldObj as &$fdo) {
                            if(strripos($fdo, $item->title_old) !==false) {
                                $fdo = str_replace($item->title_old, $item->title, $fdo);
                            }
                        }
                    }

                }
            }
        }
        return $fieldObj;
    }

    public static function getCategoryChildChain($id, $chain_ch = []) {
        $chain = ParserCategory::where('id', $id)->select('id', 'title', 'parent_id', 'url')->first();
        if($chain) {
            $chain = $chain->toArray();
            array_unshift($chain_ch, [
                'parent_id' => $chain['parent_id'],
                'title' => $chain['title'],
                'id' => $id
            ]);
        }
        if(!empty($chain['parent_id'])) {
            return CustomCategory::getCategoryChildChain($chain['parent_id'], $chain_ch);
        }
        return $chain_ch;
    }


}
