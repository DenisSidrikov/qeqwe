<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Sklad extends Model
{

    protected $fillable = ['title', 'provider_id', 'address', 'phone', 'phone2', 'address_office', 'site', 'email'];

    use HasFactory;

    public static function getSkladCategoryProdCount($sklad) {
        if(!empty($sklad)) {
            foreach ($sklad as $sk) {
                $catCount = ParserCategory::getCategoryCount($sk->id);
                $prodCount = ParseProduct::getProductCount($sk->id);
                $status = Alert::getAlertStatus($sk->id);
                $sk->categoryCount = $catCount;
                $sk->productCount = $prodCount;

//                dd(!empty($status->status_string) ? $status->status_string : "");
                $sk->alertStatus = (!empty($status->status) && $status->status == 102) ? $status->status : "";
            }
        }

        return $sklad;
    }


    public static function getProviderBySkladId($skladId){
        if($skladId) {
            $sklad = Sklad::where('id', $skladId)->first();
            if($sklad) {
                return Provider::where('id', $sklad->provider_id)->first();
            } else {
                return null;
            }
        }
        return null;
    }

    public static function getAllSkladCount() {
        return Sklad::count();
    }


}
