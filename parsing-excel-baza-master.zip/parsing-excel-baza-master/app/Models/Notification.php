<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Notification extends Model
{
    use HasFactory;

    public static function getExportNotifications($kladId) {
        return Notification::where([
            ['type', 'export'],
            ['sklad_id', $kladId],
            ['status', 1]
        ])->orderBy('updated_at', 'desc')->get();
    }

    public static function removeExportNotification($id) {
        $not = Notification::where('id', $id)->first();
        if(!empty($not)){
            $not->status = 0;
            $not->save();
            return json_encode(200);
        } else {
            return json_encode(500);
        }

    }
}
