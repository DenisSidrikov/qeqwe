<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use simplehtmldom\HtmlWeb;

class ParserCategory extends Model
{
    use HasFactory;

    public static function request($url, $post = 0){
//        $ch = curl_init();
//        curl_setopt($ch, CURLOPT_URL, $url ); // отправляем на
//        curl_setopt($ch, CURLOPT_HEADER, 0); // пустые заголовки
//        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); // возвратить то что вернул сервер
//        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 3); // следовать за редиректами
//        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);// таймаут4
//        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
//        curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/89.0.4389.128 Safari/537.36');
//        curl_setopt($ch, CURLOPT_ENCODING ,"");
//        curl_setopt($ch, CURLOPT_COOKIEJAR, public_path().'/cookie.txt'); // сохранять куки в файл
//        curl_setopt($ch, CURLOPT_COOKIEFILE,  public_path().'/cookie.txt');
//        curl_setopt($ch, CURLOPT_POST, $post!==0 ); // использовать данные в post
//        if($post)
//            curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
//        $data = curl_exec($ch);
//        curl_close($ch);
//        if($data) {
//            $data = iconv("Windows-1251", "UTF-8", $data);
//        }
//        dd($url, $data);

        $httpClient = new HtmlWeb();
        $data = $httpClient->load($url);


        return $data ? $data : "";
    }

    public static function getParentCategories($parent = null, $skaldId) {
        return ParserCategory::where([
            ['parent_id', $parent],
            ['sklad_id',$skaldId]
        ])->get();
    }

    public function getCategoryFields($categoryId) {
        if($categoryId) {
            $field = ParserCategory::where('id', $categoryId)->first();
            $field = !empty($field) ? json_decode($field->fields, JSON_UNESCAPED_UNICODE) : [];
            $fieldArray = [];
            if (!empty($field)) {
                foreach ($field as $key => $fd) {
                    if(strripos($fd, 'Продукция') === false) {
                        $fd = ParserCategory::replaceField($fd);
//                        if (strripos($fd, 'Цена') !== false) {
//                            $fieldArray[] = 'Цена';
//                            break;
//                        } else {
                            $fieldArray[] = $fd;
//                        }
                    }
                }
            }
        }

        return $fieldArray ?? [];
    }

    private function replaceField($title) {
        if(!empty($title)) {
            $replace = ProductFieldReplace::where([
                ['title_old', $title]
            ])->first();
            if(!empty($replace))
                $title = $replace->title;
        }

        return $title;
    }

    public static function setCategoryTitleReplace($id, $title)
    {
        try {
            if ($id) {
                $catRepl = CategoryTitleReplace::where('category_id', $id)->first();
                if (!empty($catRepl)) {
                    if($catRepl->title_old == $title) {
                        $catRepl->delete();
                        $category = ParserCategory::where('id', $id)->first();
                        $category->is_edited = null;
                        $category->save();
                        return json_encode(200);
                    } else {
                        $catRepl->title = $title;
                        $catRepl->save();
                        $category = ParserCategory::where('id', $id)->first();
                        $category->title = $title;
                        $category->is_edited = 1;
                        $category->save();
                        return json_encode(200);
                    }
                } else {
                    $category = ParserCategory::where('id', $id)->first();
                    $replace = [
                        "category_id" => $id,
                        "title" => $title,
                        "title_old" => $category->title,
                    ];
                    $category->title = $title;
                    $category->is_edited = 1;
                    $category->save();
                    CategoryTitleReplace::insert($replace);
                    return json_encode(200);
                }
            } else {
                return json_encode(500);
            }
        } catch (\Exception $e) {
            return json_encode(500);
        }
    }

    public static function setCategoryTitleReplaceByTitle($id, $title, $oldTitle) {
        try {
            if ($id && $title && $oldTitle) {
                $catRepl = CategoryTitleReplace::where('title', $oldTitle)->get();
//                dd($catRepl);
                if(count($catRepl)) {

                    foreach ($catRepl as $catr) {
                        if($catr->title_old == $title) {
                            $catr->delete();
                            $category = ParserCategory::where('title', $oldTitle)->get();
                            foreach ($category as $cat) {
                                $cat->is_edited = null;
                                $cat->save();
                            }
                        } else {
                            $catr->title = $title;
                            $catr->save();
                            $category = ParserCategory::where('title', $oldTitle)->get();
                            foreach ($category as $cat) {
                                $cat->title = $title;
                                $cat->is_edited = 1;
                                $cat->save();
                            }
                        }
                    }
                    return json_encode(200);

                } else {
                    $replace = [];
                    $category = ParserCategory::where('title', $oldTitle)->get();
                    if(!empty($category)){
                        foreach ($category as $cat) {
                            $replace[] = [
                                "category_id" => $cat->id,
                                "title" => $title,
                                "title_old" => $cat->title,
                            ];
                            $cat->title = $title;
                            $cat->is_edited = 1;
                            $cat->save();
                        }
                    }

                    CategoryTitleReplace::insert($replace);
                    return json_encode(200);
                }
            }

        } catch (\Exception $e) {
            return json_encode(500);
        }
    }

    public static function setFieldsTitleReplace($categoryTitle, $fields, $oldFields) {
        if($categoryTitle){
            $arrFields = [];
            $category = ParserCategory::where('title', $categoryTitle)->get();
            foreach ($category as $cat) {
                if(!empty($cat->fields)) {
                    $catFieldStr = $cat->fields;

                    if(strripos($catFieldStr, $oldFields) !== false) {
                        $cat->fields = str_replace($oldFields, $fields, $catFieldStr);
                        $cat->is_edited = 1;
                        $cat->save();
                    }

                    $products = ParseProduct::where('category_id', $cat->id)->get();
                    foreach ($products as $prod) {
                        $prodFields = $prod->field;
                        if(strripos($prodFields, $oldFields) !== false) {
                            $prod->field = str_replace($oldFields, $fields, $prodFields);
                            $prod->save();
                        }
                    }

                    $replaceField = ProductFieldReplace::where('category_id', $cat->id)->get();
                    $isExistField = 0;
                    if($replaceField) {
                        foreach ($replaceField as $repf) {
                            if($repf->title == $oldFields) {
                                $isExistField = 1;
                                $repf->title = $fields;
                                $repf->save();
                            }
                        }
                        if($isExistField == 0) {
                            $arrFields[] = [
                                "category_id" => $cat->id,
                                "title" => $fields,
                                "title_old" => $oldFields
                            ];
                        }
                    } else {
                        $arrFields[] = [
                            "category_id" => $cat->id,
                            "title" => $fields,
                            "title_old" => $oldFields
                        ];
                    }
                }
            }
            if(!empty($arrFields)) {
                ProductFieldReplace::insert($arrFields);
            }

            return json_encode(200);

        } else {
            return json_encode(500);
        }
    }

    public static function getCategoryTitle($categoryId) {
        $category = ParserCategory::where('id', $categoryId)->first();
        return $category ? $category->title : "";
    }

    public static function getCategoryCount($skladId) {
        return ParserCategory::where('sklad_id', $skladId)->count();
    }

    public static function addHasChildrenProp($categories, $skladId){
        if(!empty($categories)) {
            foreach ($categories as $cat) {
                $count = ParserCategory::where([
                    ['parent_id', $cat->id],
                    ['sklad_id', $skladId]
                ])->count();
                $cat->hasChildren = !empty($count) && $count > 0 ? true : false;
            }
        }
        return $categories;

    }

    public static function getProductCountInCategory($categories, $skladId) {
        if(!empty($categories)) {
            foreach ($categories as $cat) {
                $count = ParseProduct::where([
                    ['category_id', $cat->id],
                    ['sklad_id', $skladId]
                ])->count();
                $cat->prodCount = !empty($count) ? $count : 0;
            }
        }
        return $categories;
    }

//    public static function hasChildren($catId, $skladId){
//        $count = ParserCategory::where([
//            ['parent_id', $catId],
//            ['sklad_id', $skladId]
//        ])->count();
//        return !empty($count) && $count > 0 ? true : false;
//
//    }

    public static function setCustomCategory($categoryTitle, $title) {
        $cat = ParserCategory::where('title', $categoryTitle)->get();
        if(count($cat)) {
            foreach ($cat as $c) {
                $c->custom_category = $title;
                $c->save();
            }
            return json_encode(200);
        } else {
            return json_encode(500);
        }
    }

    public static function getCustomCategory($id) {
        $customCat = ParserCategory::where('id', $id)->select('custom_category')->first();
        return !empty($customCat->custom_category) ? $customCat->custom_category : "";
    }

    public static function removeAllCategory($skladId) {
        ParserCategory::where('sklad_id', $skladId)->delete();
    }


}
