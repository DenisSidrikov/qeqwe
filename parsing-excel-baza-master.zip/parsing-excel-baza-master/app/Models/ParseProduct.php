<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ParseProduct extends Model
{
    use HasFactory;

    public function getProductsByCategory($categoryId = null) {
        $products = ParseProduct::where('category_id', $categoryId)->get();
        foreach ($products as $prod) {
            $lastProdField = $prod->field;
            $prod->field = !empty($prod->field) ? ParseProduct::getFieldArray($prod->field) : [];
        }
        return $products;
    }

    public static function getFieldArray($field) {
        $field = $field ? json_decode($field, JSON_UNESCAPED_UNICODE) : [];
        $fieldArray = [];
        if(!empty($field)) {
            foreach ($field as $key => $fd) {
                if(strripos($key, 'Продукция') === false) {
                    $fieldArray[] = [
                        "title" => $key,
                        "value" => $fd
                    ];
                }
            }
        }
        return $fieldArray;
    }

    public static function getProductCount($skladId) {
        return ParseProduct::where('sklad_id', $skladId)->count();
    }

    public static function getAllProductCount() {
        return ParseProduct::count();
    }

    public static function removeAllProducts($skladId) {
        ParseProduct::where('sklad_id', $skladId)->delete();
    }


}
