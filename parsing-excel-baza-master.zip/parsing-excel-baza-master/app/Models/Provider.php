<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Provider extends Model
{
    protected $fillable = ['title', 'phone', 'email', 'address', 'description', 'site'];

    use HasFactory;

    public function sklads() {
        return $this->hasMany(Sklad::class);
    }

    public function getAllProviderCount() {
        return Provider::count();
    }

}
