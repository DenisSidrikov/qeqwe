<?php

namespace App\Jobs;

use App\Models\Alert;
use App\Models\Parser\MCru;
use App\Models\Parser\Mechelservice;
use App\Models\Parser\Metallotorg;
use App\Models\Parser\Prommetall;
use App\Models\Parser\Severstal;
use App\Models\ParserCategory;
use App\Models\Parser\SkatUral;
use App\Models\Sklad;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldBeUnique;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class ProcessParse implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $skladId;
    protected $parseCat = 0;

    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($skladId, $parseCat = 0)
    {
        $this->skladId = $skladId;
        $this->parseCat = $parseCat;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        if($this->skladId) {
            $provider = Sklad::getProviderBySkladId($this->skladId);
            if(!empty($provider)){
                switch ($provider->site){
                    case strripos($provider->site, 'mc.ru') !== false :
                        $mc = new MCru();
                        if($this->parseCat) {
                            $mc->refreshCategories($this->skladId);
                        } else {
                            $mc->parsing($this->skladId);
                        }
                        break;
                    case strripos($provider->site, 'mechelservice') !== false:
                        $mechel = new Mechelservice($this->skladId);
                        if($this->parseCat) {
                            $mechel->refreshCategories($this->skladId);
                        } else {
                            $mechel->parsing($this->skladId);
                        }
                        break;
                    case strripos($provider->site, 'skatural') !== false :
                        $skat = new SkatUral($this->skladId);
                        if($this->parseCat) {
                            $skat->refreshCategories();
                        } else {
                            $skat->parsing($this->skladId);
                        }
                        break;
                    case strripos($provider->site, 'pkp') !== false:
                        $pkp = new Prommetall($this->skladId);
                        if($this->parseCat) {
                            $pkp->refreshCategories();
                        } else {
                            $pkp->parsing();
                        }
                        break;
                    case strripos($provider->site, 'severstal') !== false:
                        $pkp = new Severstal($this->skladId);
                        if($this->parseCat) {
                            $pkp->refreshCategories();
                        } else {
                            $pkp->parsing();
                        }
                        break;
                    case strripos($provider->site, 'metallotorg') !== false:
                        $mt = new Metallotorg($this->skladId);
                        if($this->parseCat) {
                            $mt->refreshCategories();
                        } else {
                            $mt->parsing();
                        }
                        break;
                }
            }
//            $mc = new MCru();
//            if($this->parseCat) {
//                $mc->refreshCategories($this->skladId);
//            } else {
//                $mc->parsing($this->skladId);
//            }

        }
    }

    public function fail(\Throwable $exception)
    {
        $alertId = Alert::getLastAlertIdBySklad($this->skladId);
        Alert::errorParsing($alertId);
    }


}
