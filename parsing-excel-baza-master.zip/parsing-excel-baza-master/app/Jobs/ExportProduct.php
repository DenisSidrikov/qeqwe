<?php

namespace App\Jobs;

use App\Exports\ProductsExport;
use App\Models\Notification;
use App\Models\Sklad;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class ExportProduct implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $skladId;
    protected $notifyId;
    /**
     * Create a new job instance.
     *
     * @return void
     */
    public function __construct($skladId, $notifyId)
    {
        $this->skladId = $skladId;
        $this->notifyId = $notifyId;
    }

    /**
     * Execute the job.
     *
     * @return void
     */
    public function handle()
    {
        $skladId = $this->skladId;
        $notifyId = $this->notifyId;
        $sklad = Sklad::where('id', $skladId)->first();
        $skladTitle = $sklad->title;
        $notification = Notification::where([
            ['id', $notifyId],
            ['sklad_id', $sklad->id]
        ])->first();
        $y = date('Y');
        $m = date('m');
        $d = date('d');
        $h = date('H');

        if($skladId) {
            $pexp = new ProductsExport($this->skladId);
            if(!empty($pexp)) {
                $filename = $skladTitle.'_'.$h.'_'.$d.'_'.$m.'_'.$y.'.xlsx';
                $result = $pexp->store($filename);
                $notification->value = '<i class="ion ion-ios-checkmark-circle-outline display-4 text-success"></i><br>'
                                        .'Экспорт завершен <br>'.date('Y-m-d H:i:s', strtotime('5 hour')).'<br><div class="mt-4"><a target="_blank" class="btn btn-primary btn-sm" href="/sklad/exportfile/'.$filename.'">Скачать</a></div>';
                $notification->save();
                return $result;
            } else {
                $notification->value = 'Ошибка экспорта <br>'.date('Y-m-d H:i:s', strtotime('5 hour'));
                $notification->save();
            }

        }

    }


}
