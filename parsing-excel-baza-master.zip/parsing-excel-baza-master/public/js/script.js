$(document).ready(function () {

    //Изменение названий категорий
    $('body').on('click', '.category-title .editable-submit', function() {
        title = $(this).closest('.editableform').find('.editable-input input').val();
        oldTitle = $(this).closest('.category-title').find('.category-edit').data('title');
        id =  $(this).closest('.category-title').find('.category-edit').data('id');
        if (oldTitle != title) {
            $.post({
                url: '/api/sklad/setreplace',
                data: {
                    title: title,
                    oldTitle: oldTitle,
                    id: id
                }
            }).then((response) => {
                if (response == 200) {
                    setAlertSuccess('Название поля изменено');
                }
                if (response == 500) {
                    setAlertWarning('Произошла ошибка при измененнии поля');
                }
            });
        }
    });

    $('body').on('click', '.custom-category-title .editable-submit', function() {
        breadcrump = [];
        $('.breadcrumb-category-link').each(function(){
            breadcrump.push($(this).data('title'))
        });
        id = $(this).closest('tr').data('id');
        categoryTitle =$(this).closest('tr').find('.category-title a').text();
        title =  $(this).closest('.editableform').find('.editable-input input').val();
        oldTitle =  $(this).closest('.custom-category-title').find('.field-edit').text();
        console.log($(this).closest('.custom-category-title').find('.field-edit'), oldTitle);
        $.post({
            url: '/api/sklad/set/custumcategory',
            data: {
                title: title,
                id: id,
                oldTitle: oldTitle,
                categoryTitle: categoryTitle,
                categories: breadcrump
            }
        }).then((response) => {
            if (response == 200) {
                setAlertSuccess('Категория установлена');
            }
            if (response == 500) {
                setAlertWarning('Произошла ошибка при установлении категории');
            }
        });
    });

    function setAlertSuccess(title) {
        $('.row-alert-success').find('.alert-heading').text(title);
        $('.row-alert-success').removeClass('d-none');
        $('.row-alert-success').addClass('d-block');
        setTimeout(function () {
            $('.row-alert-success').removeClass('d-block');
            $('.row-alert-success').addClass('d-none');
        }, 3000);
    }

    function setAlertWarning(title) {
        $('.row-alert-warning').find('.alert-heading').text(title);
        $('.row-alert-warning').removeClass('d-none');
        $('.row-alert-warning').addClass('d-block');
        setTimeout(function () {
            $('.row-alert-warning').removeClass('d-block');
            $('.row-alert-warning').addClass('d-none');
        }, 3000);
    }

    $('body').on('click', '.close-notification', function () {
        card = $(this).closest('.card');
        id = card.data('id');
        $.post({
            url: '/api/sklad/remove/notification',
            data: {
                id: id
            }
        }).then((response) => {
            if (response == 200) {
                $('.row-alert-success').find('.alert-heading').text('Уведомление удалено');
                $('.row-alert-success').removeClass('d-none');
                $('.row-alert-success').addClass('d-block');
                setTimeout(function () {
                    $('.row-alert-success').removeClass('d-block');
                    $('.row-alert-success').addClass('d-none');
                }, 3000);
                card.remove();
            }

            if (response == 500) {
                $('.row-alert-warning').find('.alert-heading').text('Произошла ошибка при удалении уведомления');
                $('.row-alert-warning').removeClass('d-none');
                $('.row-alert-warning').addClass('d-block');
                setTimeout(function () {
                    $('.row-alert-warning').removeClass('d-block');
                    $('.row-alert-warning').addClass('d-none');
                }, 3000);
            }
        });

    });


    //Изменение названий характеристик
    $('body').on('click', '.field .editable-submit', function(){
        breadcrump = [];
        $('.breadcrumb-category-link').each(function(){
            breadcrump.push($(this).data('title'))
        });
        field = $(this).closest('.editableform').find('.editable-input input').val();
        oldField =  $(this).closest('.field').find('.field-edit').data("title");
        categoryTitle =$(this).closest('tr').find('.category-title a').text();
        $.post({
            url: '/api/sklad/setfields',
            data: {
                categories: breadcrump,
                field: field,
                oldField: oldField
            }
        }).then((response) => {
            if (response == 200) {
                setAlertSuccess('Характеристика установлена');
            }
            if (response == 500) {
                setAlertWarning('Произошла ошибка при установлении характеристики');
            }
        });


        // isEdit = $(this).hasClass('edit');
        // isSave = $(this).hasClass('save');
        // if(isEdit) {
        //     theadfield = $(this).parent().parent().find('th.field');
        //     theadfield.attr('contenteditable', true);
        //     theadfield.attr('style', 'color: black;');
        //     $(this).find('i').removeClass('fa-pencil-alt');
        //     $(this).find('i').addClass('fa-save');
        //     $(this).removeClass('edit');
        //     $(this).addClass('save');
        // } else if (isSave) {
        //
        //     fields = [];
        //     changed_fields = {};
        //     $('th.field').each(function (e) {
        //         fields.push($(this).text());
        //         if($(this).text() != $(this).data('title')) {
        //             changed_fields[$(this).data('title')] = $(this).text();
        //         }
        //     });
        //     console.log(changed_fields);
        //     $.post({
        //         url: '/api/sklad/setfields',
        //         data: {
        //             fields: fields,
        //             changed_fields: changed_fields,
        //             category_id: $(this).data('id')
        //         }
        //     }).then((response) => {
        //         console.log(response)
        //         if (response == 200) {
        //             $(this).find('i').removeClass('fa-save');
        //             $(this).find('i').addClass('fa-pencil-alt');
        //             $(this).removeClass('save');
        //             $(this).addClass('edit');
        //             theadfield.attr('contenteditable', false);
        //             theadfield.attr('style', 'color: #5b626b;');
        //             // $(this).data('title', titletext);
        //             $('.row-alert-success').removeClass('d-none');
        //             $('.row-alert-success').addClass('d-block');
        //             setTimeout(function () {
        //                 $('.row-alert-success').removeClass('d-block');
        //                 $('.row-alert-success').addClass('d-none');
        //             }, 3000);
        //         }
        //         if (response == 500) {
        //             $('.row-alert-warning').removeClass('d-none');
        //             $('.row-alert-warning').addClass('d-block');
        //             setTimeout(function () {
        //                 $('.row-alert-warning').removeClass('d-block');
        //                 $('.row-alert-warning').addClass('d-none');
        //             }, 3000);
        //         }
        //     });
        // }
    });


    // $(document).click(function (e){
    // var div = $(".btn.save");
    // var editfield = $('.category-title');
    // var editth = $('.table th.field');

    // if (!div.is(e.target) && div.has(e.target).length === 0 &&
    //     !editfield.is(e.target) && editfield.has(e.target).length === 0 &&
    //     !editth.is(e.target) && editth.has(e.target).length === 0
    // ) {
    //     $('.btn.save i').removeClass('fa-save');
    //     $('.btn.save i').addClass('fa-pencil-alt');
    //     $(this).removeClass('save');
    //     $(this).addClass('edit');
    //     $('.category-title a').attr('contenteditable', false);
    //     $('.category-title a').attr('style', 'color: #626ed4;');
    //     $('.table th.field').attr('contenteditable', false);
    //     $('.table th.field').attr('style', 'color: #5b626b;');
    //     $('.edit-field-btn').removeClass('save');
    //     $('.edit-field-btn').addClass('edit');
    // }
    // });




});
