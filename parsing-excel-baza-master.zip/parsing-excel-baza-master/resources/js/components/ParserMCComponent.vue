<template>
    <div>

        <div v-if="load">
            Загрузка
        </div>
        <div v-else>
            <div v-if="all.length >= 1">
                <div class="card" v-for="al in all">
                    <div class="card-body">
                        <div class="table-responsive">
                            <h3>
                                {{al.category.title}}
                            </h3>
                            <table class="table mb-0">
                                <thead>
                                    <tr>
                                        <th v-for="fields in al.head.fields">{{fields.title}}</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr v-for="prod in al.prods">
                                        <td v-for="pr in prod">
                                            {{pr}}
                                        </td>
                                    </tr>
                                </tbody>
                            </table>

                        </div>
                    </div>
                </div>
            </div>
        </div>


<!--        <div class="col-md-3" v-for="br in branch" v-if="br.parent.length >= 1">-->
<!--            <a @click="plus" href="#">{{br.title}}</a>-->


    </div>
</template>

<script>
export default {
    data: function() {
        return {
            load: 1,
            all: []
        }
    },
    mounted() {
        this.index();
        console.log('123');
    },
    props: [
        'id'
    ],
    methods: {
        index: function () {
            axios({
                method: 'get',
                url: '/api/sklad/get',
                params: { id: this.id }
            }).then((response) => {
                this.all = response.data;
                this.load = 0;
                console.log(response.data);
            })
        },
        plus: function (event) {

            // var ul = $(event.target).parent().find('ul');
            // if(ul.is(':visible')){
            //     ul.css({'display':'none'});
            // } else {
            //     ul.css({'display':'block'});
            // }
        }
    }
}
</script>
