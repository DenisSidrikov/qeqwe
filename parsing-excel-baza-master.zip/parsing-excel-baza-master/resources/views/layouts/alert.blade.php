@if (Session::has('error'))
    <div class="col-md-12">
        <div class="alert alert-danger">
{{--            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>--}}
            <p style="padding: 10px 15px;">{{ Session::get('error') }}</p>
        </div>
    </div>
@endif
@if (Session::has('success'))
    <div class="col-md-12">
        <div class="alert alert-success">
{{--            <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>--}}
            <p style="padding: 10px 15px;">{{ Session::get('success') }}</p>
        </div>
    </div>
@endif
