<div class="form-group">
    <label class="form-label" for="title">Название</label>
    <input type="text" class="form-control" name="title" id="title" maxlength="250" placeholder="ООО ТНМК" value="{{$sklad->title ?? ""}}" required>
</div>
<div class="form-group">
    <label class="form-label" for="site">Сайт</label>
    <input type="text" class="form-control" name="site" id="site" maxlength="240" placeholder="https://tnmk.ru" value="{{$sklad->site ?? ""}}">
</div>

<div class="form-group">
    <label class="form-label" for="address_office">Адрес / Город</label>
    <input type="text" class="form-control" name="address_office" id="address_office" maxlength="1000" placeholder="Фронтовых бригад 31" value="{{((!empty($sklad->address_office)) ? $sklad->address_office : ($sklad->address ?? ""))}}">
</div>
{{--@dd($provider, $provider[0])--}}
<div class="form-group">
    <label class="form-label" for="provider_id">Поставщик</label>
    <select name="provider_id" id="provider_id" class="form-control">
        <option value="0">Выбрать</option>

        @if($provider && !$provider[0])
            <option value="{{$provider->id}}"{!! ((!empty($sklad->provider_id) and $sklad->provider_id == $provider->id) or (!empty($_GET['provider']) and $_GET['provider'] == $provider->id)) ? 'selected' : '' !!}>{{$provider->title}}</option>
        @else
            @foreach($provider as $prov)
                <option value="{{$prov->id}}"{!! ((!empty($sklad->provider_id) and $sklad->provider_id == $prov->id) or (!empty($_GET['provider']) and $_GET['provider'] == $prov->id)) ? 'selected' : '' !!}>{{$prov->title}}</option>
            @endforeach
        @endif
    </select>
</div>
<input type="hidden" name="prev_url" value="{{URL::previous()}}">
