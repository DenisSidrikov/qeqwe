<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>@hasSection('title') @yield('title') - База Поставщиков @else Парсер @endif</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description" />
    <meta content="Themesbrand" name="author" />

    <meta name="csrf-token" content="{{ csrf_token() }}">
    <!-- App favicon -->
    <link rel="shortcut icon" href="{{asset('assets/images/favicon.ico')}}">

    <link href="{{asset('assets/libs/chartist/chartist.min.css')}}" rel="stylesheet">
    <meta name="robots" content="noindex">
    <meta name="googlebot" content="noindex">

    <!-- Bootstrap Css -->
    <link href="{{asset('assets/css/bootstrap.min.css')}}" rel="stylesheet" type="text/css" />
    <link href="{{asset('assets/libs/bootstrap-editable/css/bootstrap-editable.css')}}" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="{{asset('assets/css/icons.min.css')}}" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="{{asset('assets/css/app.min.css')}}" rel="stylesheet" type="text/css" />


    @hasSection('script')
        @yield('script')
    @endif

</head>

<body data-sidebar="dark">

    <div id="app">

        <header id="page-topbar">
            <div class="navbar-header">
                <div class="d-flex">
                    <!-- LOGO -->
                    <div class="navbar-brand-box">
                        <a href="/" class="logo logo-dark">
                            <span class="logo-sm">
                                <img src="{{asset('assets/images/logo.svg')}}" alt="" height="22">
                            </span>
                            <span class="logo-lg">
                                <img src="{{asset('assets/images/logo-dark.png')}}" alt="" height="17">
                            </span>
                        </a>

                        <a href="/" class="logo logo-light">
                            <span class="logo-sm">
                                <img src="{{asset('assets/images/logo-sm.png')}}" alt="" height="22">
                            </span>
                            <span class="logo-lg">
                                <img src="{{asset('assets/images/logo-light.png')}}" alt="" height="18">
                            </span>
                        </a>
                    </div>

                    <button type="button" class="btn btn-sm px-3 font-size-24 header-item waves-effect" id="vertical-menu-btn">
                        <i class="mdi mdi-menu"></i>
                    </button>
                    @if((!Request::is('/')))
                    <a href="{{back()->getTargetUrl()}}" class="btn btn-sm px-3 font-size-24 header-item pt-3" >
                        <i class="mdi mdi-arrow-left"></i>
                        <span>Назад</span>
                    </a>
                    @endif


                </div>

            </div>
        </header>

        <!-- ========== Left Sidebar Start ========== -->
        <div class="vertical-menu">

            <div data-simplebar class="h-100">

                <!--- Sidemenu -->
                <div id="sidebar-menu">
                    <!-- Left Menu Start -->
                    <ul class="metismenu list-unstyled" id="side-menu">

                        <li>
                            <a href="/" class="waves-effect">
{{--                                <i class="ti-home"></i>--}}
{{--                                <span class="badge badge-pill badge-primary float-right">2</span>--}}
                                <span>Главная</span>
                            </a>
                        </li>
                        <li {!! (Request::is('provider') or Request::is('provider/*')) ? 'class="mm-active"' : '' !!}>
                            <a href="/provider" class="waves-effect {{ (Request::is('provider') or Request::is('provider/*')) ? 'active' : '' }}">
                                <span>Поставщики</span>
                            </a>
                        </li>
{{--                        <li {!! (Request::is('sklad') or Request::is('sklad/*')) ? 'class="mm-active"' : '' !!}>--}}
{{--                            <a href="/sklad" class="waves-effect {{ (Request::is('sklad') or Request::is('sklad/*')) ? 'active' : '' }}">--}}
{{--                                <span>Склады</span>--}}
{{--                            </a>--}}
{{--                        </li>--}}

                    </ul>
                </div>
                <!-- Sidebar -->
            </div>
        </div>
        <!-- Left Sidebar End -->

        <!-- ============================================================== -->
        <!-- Start right Content here -->
        <!-- ============================================================== -->
        <div class="main-content">
            @yield('content')
            <footer class="footer">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-12">
                            © {{date('Y')}} генерация excel файлов для базы поставщиков
                        </div>
                    </div>
                </div>
            </footer>

        </div>
        <!-- end main content-->

    </div>
    <!-- END layout-wrapper -->

    <!-- Right Sidebar -->
    <div class="right-bar">
        <div data-simplebar class="h-100">


            <!-- Settings -->
            <hr class="mt-0" />
            <h6 class="text-center">Choose Layouts</h6>

            <div class="p-4">
                <div class="mb-2">
                    <img src="assets/images/layouts/layout-1.jpg" class="img-fluid img-thumbnail" alt="">
                </div>
                <div class="custom-control custom-switch mb-3">
                    <input type="checkbox" class="custom-control-input theme-choice" id="light-mode-switch" checked />
                    <label class="custom-control-label" for="light-mode-switch">Light Mode</label>
                </div>

                <div class="mb-2">
                    <img src="assets/images/layouts/layout-2.jpg" class="img-fluid img-thumbnail" alt="">
                </div>
                <div class="custom-control custom-switch mb-3">
                    <input type="checkbox" class="custom-control-input theme-choice" id="dark-mode-switch" data-bsStyle="assets/css/bootstrap-dark.min.css"
                           data-appStyle="assets/css/app-dark.min.css" />
                    <label class="custom-control-label" for="dark-mode-switch">Dark Mode</label>
                </div>

                <div class="mb-2">
                    <img src="assets/images/layouts/layout-3.jpg" class="img-fluid img-thumbnail" alt="">
                </div>
                <div class="custom-control custom-switch mb-5">
                    <input type="checkbox" class="custom-control-input theme-choice" id="rtl-mode-switch" data-appStyle="assets/css/app-rtl.min.css" />
                    <label class="custom-control-label" for="rtl-mode-switch">RTL Mode</label>
                </div>

                <a href="https://1.envato.market/grNDB" class="btn btn-primary btn-block mt-3" target="_blank"><i class="mdi mdi-cart mr-1"></i> Purchase Now</a>

            </div>

        </div> <!-- end slimscroll-menu-->
    </div>
    <!-- /Right-bar -->




    <!-- Right bar overlay-->
    <div class="rightbar-overlay"></div>

    <!-- JAVASCRIPT -->
    <script src="{{asset('assets/libs/jquery/jquery.min.js')}}"></script>
    <script src="{{asset('assets/libs/bootstrap/js/bootstrap.bundle.min.js')}}"></script>
    <script src="{{asset('assets/libs/metismenu/metisMenu.min.js')}}"></script>
    <script src="{{asset('assets/libs/simplebar/simplebar.min.js')}}"></script>
    <script src="{{asset('assets/libs/node-waves/waves.min.js')}}"></script>
    <script src="{{asset('assets/libs/moment/min/moment.min.js')}}"></script>
    <script src="{{asset('assets/libs/bootstrap-editable/js/index.js')}}"></script>

    <!-- Peity chart-->
{{--    <script src="{{asset('assets/libs/peity/jquery.peity.min.js')}}"></script>--}}

    <!-- Plugin Js-->
{{--    <script src="{{asset('assets/libs/chartist/chartist.min.js')}}"></script>--}}
{{--    <script src="{{asset('assets/libs/chartist-plugin-tooltips/chartist-plugin-tooltip.min.js')}}"></script>--}}

{{--    <script src="{{asset('assets/js/pages/dashboard.init.js')}}"></script>--}}


{{--    <script src="{{asset('assets/js/pages/jquery.dataTables.min.js')}}"></script>--}}
{{--    <script src="{{asset('assets/libs/table-edits/build/table-edits.min.js')}}"></script>--}}
{{--    <script src="{{asset('assets/js/pages/table-editable.init.js')}} "></script>--}}
{{--    <script src="{{asset('assets/js/app.js')}}"></script>--}}
    <script src="{{asset('assets/js/pages/form-xeditable.init.js')}}"></script>
    <script src="{{asset('/js/script.js')}}"></script>
    <script src="{{asset('assets/js/app.js')}}"></script>

    @hasSection('script')
        @yield('script')
    @endif

</body>

</html>
