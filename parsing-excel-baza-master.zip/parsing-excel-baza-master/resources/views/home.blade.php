
@extends('layouts.app')

@section('content')

    <div class="page-content">
        <div class="container-fluid">

            <div class="p-5 mb-4 bg-light rounded-3">
                <div class="container-fluid py-5">
                    <div class="row">
                        <div class="col-4">
                            <div class="card bg-primary">
                                <div class="card-body">
                                    <div class="text-center text-white py-4">
                                        <h5 class="mb-4 text-white-50 font-size-16">Поставщиков</h5>
                                        <h1>{{$providerCount}}</h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="card bg-primary">
                                <div class="card-body">
                                    <div class="text-center text-white py-4">
                                        <h5 class="mb-4 text-white-50 font-size-16">Складов</h5>
                                        <h1>{{$skladCount}}</h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-4">
                            <div class="card bg-primary">
                                <div class="card-body">
                                    <div class="text-center text-white py-4">
                                        <h5 class="mb-4 text-white-50 font-size-16">Товаров</h5>
                                        <h1>{{number_format($prodCount, 0, " ", " ")}}</h1>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->


@endsection
