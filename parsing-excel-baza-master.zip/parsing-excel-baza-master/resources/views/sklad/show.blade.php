@extends('layouts.app')

@section('title', 'Склады')

@section('content')

    <div class="page-content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-6 mt-5">
                    <h1>{{$sklad->title}}</h1>
                </div>

                <div class="col-6 mt-5">
                    @if(!empty($status))
                        @if(!empty($status->status) && $status->status == 102)
                            <div class="alert alert-warning mb-1" role="alert">
                                <h4 class="alert-heading font-18">{{$status->status_string}}</h4>
                                <div>
                                    <div class="spinner-grow text-warning  m-1" role="status">
                                        <span class="sr-only">Loading...</span>
                                    </div>
                                    <div class="spinner-grow text-warning  m-1" role="status">
                                        <span class="sr-only">Loading...</span>
                                    </div>
                                    <div class="spinner-grow text-warning  m-1" role="status">
                                        <span class="sr-only">Loading...</span>
                                    </div>
                                </div>
                            </div>
                        @endif
                    @endif
                </div>

            </div>

            <!-- start page title -->
            <div class="row align-items-center mt-4">
                <div class="col-6">

                        <div class="row">
                            <div class="col-6">
                                @if($categoryCount)
                                    <a href="{{route('sklad.parsecat', $sklad)}}" class="btn  btn-success mb-3 d-grid w-100">Обновить</a>
                                @else
                                    <a href="{{route('sklad.parsing', $sklad)}}" class="btn  btn-success mb-3 d-grid w-100">Спарсить</a>
                                @endif
                                    <a href="{{route('sklad.export', $sklad)}}" class="btn  btn-success mb-3 d-grid w-100">Экспорт</a>
                            </div>

                        </div>


                </div>
                <div class="col-6">
                    <div class="row">
                    @if(!empty($categoryCount))
                        <div class="col-6">
                            <div class="card mini-stat bg-primary text-white">
                                <div class="card-body">
                                    <div class="mb-4">
                                        <h5 class="font-size-16 text-uppercase text-white-50">Категории:</h5>
                                        <h4 class="fw-medium font-size-24">{{$categoryCount}}</h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endif
                    @if(!empty($productCount))
                        <div class="col-6">
                            <div class="card mini-stat bg-primary text-white">
                                <div class="card-body">
                                    <div class="mb-4">
                                        <h5 class="font-size-16 text-uppercase text-white-50">Товары:</h5>
                                        <h4 class="fw-medium font-size-24">{{$productCount}}</h4>
                                    </div>
                                </div>
                            </div>
                        </div>
                    @endif
                    </div>
                </div>
            </div>
            <div class="page-title-box">
                <div class="row align-items-center">
                    <div class="col-md-12">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item active" aria-current="page">
                                <a href="/sklad/{{$sklad->id}}">{{$sklad->title}}</a>
                            </li>
                            @if(!empty($breadcrump))
                                @foreach($breadcrump as $br)
                                    <li class="breadcrumb-item">
                                        <a href="/sklad/{{$sklad->id}}?category_id={{$br['id']}}" data-title="{{$br['title']}}" class="breadcrumb-category-link">{{$br['title']}}</a>
                                    </li>
                                @endforeach
                            @endif

                        </ol>
                    </div>

                </div>
            </div>

            <div class="row d-none row-alert-success">
                <div class="col-6 mb-2 ">
                    <div class="">
                        <div class="alert alert-success mb-1" role="alert">
                            <h5 class="alert-heading font-18">Название поля изменено</h5>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row d-none row-alert-warning">
                <div class="col-6 mb-2 ">
                    <div class="">
                        <div class="alert alert-warning mb-1" role="alert">
                            <h5 class="alert-heading font-18">Произошла ошибка при измененнии поля</h5>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
            @if(!empty($category) && count($category))

                <div class="col-9">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Категории</h4>
                            <div class="table-responsive">
                                <table class="table table-striped ">
                                    <thead>
                                        <th data-field="title">Название</th>
                                        <th>Ссылка</th>
                                        <th>Указать категорию</th>
                                        <th>Количество товаров</th>
                                    </thead>
                                    <tbody>
                                        @foreach($category as $cat)
{{--                                            @dd($category, !empty($cat->hasChildren), !$cat->hasChildren)--}}
                                            @if(!empty($cat->title))
                                                <tr data-id="{{$cat->id}}" >
                                                    <td class="category-title" style="width: 35%;">
                                                        <a href="#" data-type="text" data-pk="1" data-id="{{$cat->id}}" data-title="{{$cat->title}}" class="editable editable-click category-edit" style="">{{$cat->title}}</a>
                                                    </td>

                                                    <td style="width: 20%;">
                                                        <a href="/sklad/{{$sklad->id}}?category_id={{$cat->id}}" >Перейти <i class="mdi mdi-arrow-right h5"></i></a>
                                                    </td>

                                                    <td class="custom-category-title" >
                                                        @if(!$cat->hasChildren)
                                                        <a href="#" data-type="text" data-pk="1" data-title="Enter username" data-placeholder="Required" class="editable editable-click field-edit" style="">
                                                            {{$cat->custom_category ?? "Пусто"}}
                                                        </a>
                                                        @endif
                                                    </td>
                                                    <td class="text-center">
                                                        @if(!empty($cat->prodCount))
                                                            {{$cat->prodCount}}
                                                        @endif
                                                    </td>
                                                </tr>
                                            @endif
                                        @endforeach
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div> <!-- end col -->
            @endif
            @if(!empty($products) && count($products))
                <div class="col-9">
                    <div class="card">
                        <div class="card-body">
                            <h4 class="card-title">Товары</h4>
                            <div class="table-responsive">
                                <table class="table table-editable table-nowrap align-middle table-edits">
                                    <thead>
                                    <tr>
                                        <th>Название</th>
                                        @if(!empty($fields))
                                            @foreach($fields as $key => $fd)
                                                <th class="field" data-title="{{$key}}">
                                                    <a href="#" data-type="text" data-pk="1" data-title="{{$key}}" class="editable editable-click field-edit" style="">{{$fd}}</a>
                                                </th>
                                            @endforeach
                                        @endif
                                    </tr>

                                    </thead>
                                    <tbody>
                                    @foreach($products as $prod)
                                        <tr data-id="{{$prod->id}}" >
                                            <td data-field="title" >
                                                    {{$prod->title}}
                                            </td>
                                            @foreach($prod->field as $fd)
                                                <td data-field="url" >{{$fd['value']}}</td>
                                            @endforeach
{{--                                            <td style="width: 100px">--}}
{{--                                                <a class="btn btn-secondary btn-sm edit" title="Edit">--}}
{{--                                                    <i class="fas fa-pencil-alt"></i>--}}
{{--                                                </a>--}}
{{--                                            </td>--}}
                                        </tr>
                                    @endforeach
                                    </tbody>
                                </table>
                            </div>

                        </div>
                    </div>
                </div> <!-- end col -->

            @endif
            @if(!empty($notification) && count($notification))



                    <div class="col-md-3">
                        @foreach($notification as $not)
                            @if(!empty($not->value))
                        <div class="card text-center" data-id="{{$not->id}}">
                            <div class="card-body">
                                <div class="modal-header">
                                    <h5 class="modal-title">Уведомление</h5>
                                    <button type="button" class="btn fas fa-times close-notification"  aria-label="Close"><i class="fas times"></i> </button>
                                </div>
                                <div class="py-4">
                                    {!! $not->value !!}
{{--                                    <i class="ion ion-ios-checkmark-circle-outline display-4 text-success"></i>--}}
{{--                                    <h5 class="text-primary mt-4">Order Successful</h5>--}}
{{--                                    <p class="text-muted">Thanks you so much for your order.</p>--}}
{{--                                    <div class="mt-4">--}}
{{--                                        <a href="" class="btn btn-primary btn-sm">Chack Status</a>--}}
{{--                                    </div>--}}
                                </div>

                            </div>
                        </div>
                            @endif
                        @endforeach
                    </div>

            @endif
            </div>

        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->

@endsection


