<div class="form-group">
    <label class="form-label" for="title">Название</label>
    <input type="text" class="form-control" name="title" id="title" maxlength="250" placeholder="ООО ТНМК" value="{{$sklad->title ?? ""}}" required>
</div>
{{--<div class="form-group">--}}
{{--    <label class="form-label" for="phone">Телефон</label>--}}
{{--    <input type="text" class="form-control" name="phone" id="phone" maxlength="240" placeholder="+7 (343) 3-180-170" value="{{$sklad->phone ?? ""}}" >--}}
{{--</div>--}}
{{--<div class="form-group">--}}
{{--    <label class="form-label" for="phone2">Телефон 2</label>--}}
{{--    <input type="text" class="form-control" name="phone2" id="phone2" maxlength="240" placeholder="+7 (343) 3-180-170" value="{{$sklad->phone2 ?? ""}}">--}}
{{--</div>--}}
<div class="form-group">
    <label class="form-label" for="site">Сайт</label>
    <input type="text" class="form-control" name="site" id="site" maxlength="240" placeholder="https://tnmk.ru" value="{{$sklad->site ?? ""}}">
</div>
<div class="form-group">
    <label class="form-label" for="address_office">Адрес / Город</label>
    <input type="text" class="form-control" name="address_office" id="address_office" maxlength="1000" placeholder="Фронтовых бригад 31" value="{{((!empty($sklad->address_office)) ? $sklad->address_office : ($sklad->address ?? ""))}}">
</div>
{{--<div class="form-group">--}}
{{--    <label class="form-label" for="address">Адрес склада</label>--}}
{{--    <input type="text" class="form-control" name="address" id="address" maxlength="1000" placeholder="Россия, Свердловская область, Екатеринбург, улица Малышева, 51, оф 16/05" value="{{$sklad->address ?? ""}}" >--}}
{{--</div>--}}
{{--<div class="form-group">--}}
{{--    <label class="form-label" for="email">Email</label>--}}
{{--    <input type="text" class="form-control" name="email" id="email" maxlength="200" placeholder="" value="{{ $sklad->email ?? '' }}">--}}
{{--</div>--}}
<div class="form-group">
    <label class="form-label" for="provider_id">Поставщик</label>
    <select name="provider_id" id="provider_id" class="form-control">
        <option value="0">Выбрать</option>
        @foreach($provider as $pro)
            <option value="{{$pro->id}}"{!! ((!empty($sklad->provider_id) and $sklad->provider_id == $pro->id) or (!empty($_GET['provider']) and $_GET['provider'] == $pro->id)) ? 'selected' : '' !!}>{{$pro->title}}</option>
        @endforeach
    </select>
</div>
{{--<div class="form-group">--}}
{{--    <label class="form-label" for="rating">Рйтинг <smile>(Пока не трогать)</smile></label>--}}
{{--    <input type="text" class="form-control" name="rating" id="rating" placeholder="0" value="{{$sklad->rating ?? "0"}}">--}}
{{--</div>--}}
<input type="hidden" name="prev_url" value="{{URL::previous()}}">
