@extends('layouts.app')

@section('title', 'Добавление склада')

@section('content')

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <div class="page-title-box">
                        <h4 class="font-size-18">Редактирование склада</h4>
{{--                        @if($providerSelected)--}}
{{--                            <ol class="breadcrumb mb-0">--}}
{{--                                <li class="breadcrumb-item active">Для {{$providerSelected->title}}</li>--}}
{{--                            </ol>--}}
{{--                        @endif--}}
                    </div>
                </div>

            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            @include('layouts.alert')
                            <form class="form-horizontal" action="{{route('sklad.update', $sklad)}}" method="post">
                                <input type="hidden" name="_method" value="put">
                                {{ csrf_field() }}
                                {{-- Form include --}}
                                @include('layouts.form')
                                <div class="float-right">
                                    <input class="btn btn-info" type="submit" value="Сохранить">
                                </div>
                            </form>

                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->

        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->

@endsection


