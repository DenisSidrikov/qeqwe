<div class="form-group">
    <label class="form-label" for="title">Название</label>
    <input type="text" class="form-control" name="title" id="title" maxlength="250" placeholder="ООО ТНМК" value="{{$provider->title ?? ""}}" required>
</div>
<div class="form-group">
    <label class="form-label" for="site">Адрес сайта</label>
    <input type="text" class="form-control" name="site" id="site" maxlength="250" placeholder="tnmk.ru" value="{{$provider->site ?? ""}}">
</div>
