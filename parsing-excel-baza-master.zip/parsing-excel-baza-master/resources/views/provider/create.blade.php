@extends('layouts.app')

@section('title', 'Добавление провайдера')

@section('content')

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <div class="page-title-box">
                        <h4 class="font-size-18">Добавление провайдера</h4>
                    </div>
                </div>

            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            @include('layouts.alert')
                            <form class="form-horizontal" action="{{route('provider.store')}}" method="post">
                                {{ csrf_field() }}
                                {{-- Form include --}}
                                @include('provider.form')
                                <div class="float-right">
                                    <input class="btn btn-info" type="submit" value="Добавить">
                                </div>
                            </form>

                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->

        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->

@endsection

@section('style')
    {{--    <link href="{{asset('assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')}}" rel="stylesheet" type="text/css" />--}}
    {{--    <link href="{{asset('assets/libs/datatables.net-autoFill-bs4/css/autoFill.bootstrap4.min.css')}}" rel="stylesheet" type="text/css" />--}}
    {{--    <link href="{{asset('assets/libs/datatables.net-keytable-bs4/css/keyTable.bootstrap4.min.css')}}" rel="stylesheet" type="text/css" />--}}
    {{--    <link href="{{asset('assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')}}" rel="stylesheet" type="text/css" />--}}
@endsection

@section('script')
    <!-- Required datatable js -->
    {{--    <script src="{{asset('assets/libs/datatables.net/js/jquery.dataTables.min.js')}}"></script>--}}
    {{--    <script src="{{asset('assets/libs//datatables.net-bs4/js/dataTables.bootstrap4.min.js')}}"></script>--}}

    {{--    <script src="{{asset('assets/libs/datatables.net-autoFill/js/dataTables.autoFill.min.js')}}"></script>--}}
    {{--    <script src="{{asset('assets/libs/datatables.net-autoFill-bs4/js/autoFill.bootstrap4.min.js')}}"></script>--}}

    {{--    <script src="{{asset('assets/libs/datatables.net-keytable/js/dataTables.keyTable.min.js')}}"></script>--}}

    {{--    <!-- Responsive examples -->--}}
    {{--    <script src="{{asset('assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')}}"></script>--}}

    {{--    <script src="{{asset('assets/libs/bootstrap-editable/js/index.js')}}"></script>--}}

    {{--    <script src="{{asset('assets/js/pages/table-editable.init.js')}}"></script>--}}
@endsection
