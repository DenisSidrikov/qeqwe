@extends('layouts.app')

@section('title', 'Провайдеры')

@section('content')

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <div class="page-title-box">
                        <h4 class="font-size-18 mb-3">Провайдеры</h4>
                        <a href="{{route('sklad.create', ['provider' => $provider->id])}}" class="btn btn-success mt-2">Добавить склад</a>
                    </div>
                </div>

            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">

                                <div class="table-responsive">
                                    <table class="table mb-0">
                                        <thead>
                                        <tr>
                                            <th width="50">#</th>
                                            <th>Название</th>
                                            <th>Количество категорий</th>
                                            <th>Количество товаров</th>
                                            <th>Загрузка</th>
                                            <th></th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @forelse($provider->sklads as $skladKey => $sklad)
                                        <tr>
                                            <th scope="row">{{$skladKey+1}}</th>
                                            <td>
                                                <a href="{{route('sklad.show', $sklad)}}">{{{$sklad->title}}}</a>
                                            </td>
                                            <td>
                                                {{$sklad->categoryCount}}
                                            </td>
                                            <td>
                                                {{$sklad->productCount}}
                                            </td>
                                            <td>
                                                @if(!empty($sklad->alertStatus))
                                                    <div class="spinner-grow text-warning  m-1" role="status">
                                                        <span class="sr-only">Loading...</span>
                                                    </div>
                                                @endif
                                            </td>
                                            <td>
                                                <a href="{{route('sklad.edit', $sklad)}}" class="btn btn-secondary btn-sm edit float-right ml-2" title="Edit">
                                                    <i class="fas fa-pencil-alt"></i>
                                                </a>
                                            </td>
                                        </tr>
                                        @empty
                                            <tr>
                                                <td style="text-align: center" colspan="12">Нет склада</td>
                                            </tr>
                                        @endforelse
                                        </tbody>
                                    </table>

                                </div>

                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->

        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->

@endsection

@section('style')
{{--    <link href="{{asset('assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')}}" rel="stylesheet" type="text/css" />--}}
{{--    <link href="{{asset('assets/libs/datatables.net-autoFill-bs4/css/autoFill.bootstrap4.min.css')}}" rel="stylesheet" type="text/css" />--}}
{{--    <link href="{{asset('assets/libs/datatables.net-keytable-bs4/css/keyTable.bootstrap4.min.css')}}" rel="stylesheet" type="text/css" />--}}
{{--    <link href="{{asset('assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')}}" rel="stylesheet" type="text/css" />--}}
@endsection

@section('script')
    <!-- Required datatable js -->
{{--    <script src="{{asset('assets/libs/datatables.net/js/jquery.dataTables.min.js')}}"></script>--}}
{{--    <script src="{{asset('assets/libs//datatables.net-bs4/js/dataTables.bootstrap4.min.js')}}"></script>--}}

{{--    <script src="{{asset('assets/libs/datatables.net-autoFill/js/dataTables.autoFill.min.js')}}"></script>--}}
{{--    <script src="{{asset('assets/libs/datatables.net-autoFill-bs4/js/autoFill.bootstrap4.min.js')}}"></script>--}}

{{--    <script src="{{asset('assets/libs/datatables.net-keytable/js/dataTables.keyTable.min.js')}}"></script>--}}

{{--    <!-- Responsive examples -->--}}
{{--    <script src="{{asset('assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')}}"></script>--}}

{{--    <script src="{{asset('assets/libs/bootstrap-editable/js/index.js')}}"></script>--}}

{{--    <script src="{{asset('assets/js/pages/table-editable.init.js')}}"></script>--}}
@endsection
