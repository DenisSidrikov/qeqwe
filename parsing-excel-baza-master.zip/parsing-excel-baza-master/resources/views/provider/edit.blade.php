@extends('layouts.app')

@section('title', 'Добавление провайдера')

@section('content')

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <div class="page-title-box">
                        <h4 class="font-size-18">Редактирование провайдера</h4>
                    </div>
                </div>

            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            @include('layouts.alert')
                            <form class="form-horizontal" action="{{route('provider.update', $provider)}}" method="post">
                                {{ csrf_field() }}
                                <input type="hidden" name="_method" value="put">
                                {{-- Form include --}}
                                @include('provider.form')
                                <div class="float-right">
                                    <input class="btn btn-info" type="submit" value="Сохранить">
                                </div>
                            </form>

                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->

        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->

@endsection

