@extends('layouts.app')

@section('title', 'Провайдеры')

@section('content')

    <div class="page-content">
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row align-items-center">
                <div class="col-sm-6">
                    <div class="page-title-box">
                        <h4 class="font-size-18 mb-3">Провайдеры</h4>
                        <a href="{{route('provider.create')}}" class="btn btn-success mt-3">Добавить поставщика</a>
                    </div>
                </div>

            </div>

            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">

                                <div class="table-responsive">
                                    <table class="table mb-0">
                                        <thead>
                                        <tr>
                                            <th width="50">#</th>
                                            <th>Название</th>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        @foreach($provider as $keyProv => $prov)
                                        <tr>
                                            <th scope="row">{{$keyProv+1}}</th>
                                            <td>
                                                <a href="{{route('provider.show', $prov)}}">{{{$prov->title}}}</a>
                                                <a href="{{route('provider.edit', $prov)}}" class="btn btn-secondary btn-sm edit float-right ml-2" data-provider-id="{{$prov->id}}" title="Edit">
                                                    <i class="fas fa-pencil-alt"></i>
                                                </a>

                                            </td>
                                        </tr>
                                        @endforeach
                                        </tbody>
                                    </table>

                                </div>

                        </div>
                    </div>
                </div> <!-- end col -->
            </div> <!-- end row -->

        </div> <!-- container-fluid -->
    </div>
    <!-- End Page-content -->

@endsection

@section('style')
{{--    <link href="{{asset('assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')}}" rel="stylesheet" type="text/css" />--}}
{{--    <link href="{{asset('assets/libs/datatables.net-autoFill-bs4/css/autoFill.bootstrap4.min.css')}}" rel="stylesheet" type="text/css" />--}}
{{--    <link href="{{asset('assets/libs/datatables.net-keytable-bs4/css/keyTable.bootstrap4.min.css')}}" rel="stylesheet" type="text/css" />--}}
{{--    <link href="{{asset('assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')}}" rel="stylesheet" type="text/css" />--}}
@endsection

@section('script')
    <!-- Required datatable js -->
{{--    <script src="{{asset('assets/libs/datatables.net/js/jquery.dataTables.min.js')}}"></script>--}}
{{--    <script src="{{asset('assets/libs//datatables.net-bs4/js/dataTables.bootstrap4.min.js')}}"></script>--}}

{{--    <script src="{{asset('assets/libs/datatables.net-autoFill/js/dataTables.autoFill.min.js')}}"></script>--}}
{{--    <script src="{{asset('assets/libs/datatables.net-autoFill-bs4/js/autoFill.bootstrap4.min.js')}}"></script>--}}

{{--    <script src="{{asset('assets/libs/datatables.net-keytable/js/dataTables.keyTable.min.js')}}"></script>--}}

{{--    <!-- Responsive examples -->--}}
{{--    <script src="{{asset('assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')}}"></script>--}}

{{--    <script src="{{asset('assets/libs/bootstrap-editable/js/index.js')}}"></script>--}}

{{--    <script src="{{asset('assets/js/pages/table-editable.init.js')}}"></script>--}}
@endsection
