<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

//Route::get('/', function () {
//    return view('welcome');
//});

Auth::routes([
    'confirm' => false,
    'forgot' => false,
    'login' => true,
    'register' => false,
    'reset' => false,
    'verification' => false,
]);

Route::group(['middleware' => 'auth'], function() {
    Route::get('/', [App\Http\Controllers\HomeController::class, 'index'])->name('home')->middleware('auth');

    Route::resource('provider', App\Http\Controllers\ProviderController::class);

    Route::get('/test', [App\Http\Controllers\TestController::class, 'test']);

    Route::resource('sklad', App\Http\Controllers\SkladController::class);
    Route::get('sklad/parsing/{sklad}', [App\Http\Controllers\SkladController::class, 'parsing'])->name('sklad.parsing');
    Route::get('sklad/parsecat/{sklad}', [App\Http\Controllers\SkladController::class, 'refreshCategories'])->name('sklad.parsecat');
    Route::get('sklad/export/{sklad}', [App\Http\Controllers\SkladController::class, 'export'])->name('sklad.export');
    Route::get('/sklad/exportfile/{filename}', [\App\Http\Controllers\SkladController::class, 'exportProdFile'])->name('sklad.export.file');

});

