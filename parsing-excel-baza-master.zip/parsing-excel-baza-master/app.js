//npm install mysql
//npm install express --save

const express = require('express');
const app = express();
const hostname = '141.101.196.167';
const port = '5050';
// const hostname = '127.0.0.1';
// const port = '3356';

var jsdom = require('jsdom');
$ = require('jquery')(new jsdom.JSDOM().window);

const mysql = require('mysql');
var request = require('request');

pool = mysql.createPool({
    host: "127.0.0.1",
    user: "parser",
    database: "parser",
    password: "dW0tL9hW1ixQ8m"
});

// pool = mysql.createPool({
//     host: "127.0.0.1",
//     user: "root",
//     database: "parser",
//     password: ""
// });

var bodyParser = require('body-parser');
app.use(bodyParser.json()); // support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // support encoded bodies

app.get('/', (req, res) => {
    res.send('Ошибка 1');
});

app.param('skladId', function(req, res, next, id) {
    req.id = id;
    next();
});

const puppeteer = require('puppeteer')

async function startBrowser(){
    let browser;
    try {
        console.log("Opening the browser......");
        browser = await puppeteer.launch({
            headless: true,
            args:  ["--no-sandbox", "--disable-setuid-sandbox"]
        });
    } catch (err) {
        console.log("Could not create a browser instance => : ", err);
    }
    return browser;
}


async function auth(browserInstance){
    let browser;
    try{
        browser = await browserInstance;
        let page = await browser.newPage();
        await page.goto('https://yandex.ru/');//заходим на сайт
    }
    catch(err){
        console.log("Could not resolve the browser instance => ", err);
    }
}

app.get('/api/parse/:skladId', function(req, res) {
    skladId = req.id;
    console.log(`Parsing  - ` + skladId);
    if(req.id) {
        if (/^-?[\d.]+(?:e-?\d+)?$/.test(req.id)) {
            scrapeAll(skladId)

            async function scrapeAll(skladId) {
                let browserInstance = await startBrowser();
                auth(browserInstance)

                let browser;
                try {
                    browser = await browserInstance;
                    let page = await browser.newPage();

                    await page.goto('https://market.severstal.com/ru/ru');
                    // await page.waitForTimeout(2000);
                    await page.waitForSelector('.categories .category-list__item a');

                    console.log(`Parsing catalog`);
                    let catLinkObject = await getCategoryLinksFromCatalog(page);
                    await writeCategoryLinks(catLinkObject, skladId);
                    await page.waitForTimeout(2000);

                    page.close();

                    let categoryLinks = await getAllCategory(skladId);
                    if(categoryLinks.length) {
                        await asyncForEach(categoryLinks, async (value, index) => {
                            await parsePageContent(browser, value);
                        }).then(_ => {
                            stopAlert();
                            browser.close();
                            console.log('Finish')
                        });
                    }

                } catch (err) {
                    console.log("Could not resolve the browser instance => ", err);
                }
            }

            async function parsePageContent(browser, value) {
                let page = await browser.newPage();
                let currentUrl = value.url;
                console.log("value.url", value.url);
                await page.goto(value.url + '?pageSize=150');
                // await page.waitForTimeout(5000);
                await page.waitForSelector('h1');

                let pageCount = await getPaginateCount(page);
                console.log("pageCount", pageCount);
                await page.waitForTimeout(1000);
                if(pageCount > 1) {
                    const pageArr = [];
                    let pagurl = page.url();
                    let products = await getProductsFromPage(page);
                    let category = await getCategory(page);
                    await setCategory(category, products, currentUrl);
                    console.log("category", category);
                    await setProducts(products, currentUrl);
                    page.close();
                    for(let i = 2; i <= pageCount; i++) {
                        let page = await browser.newPage();
                        await page.goto(pagurl+"?page="+i);
                        await page.waitForTimeout(6000);
                        let products = await getProductsFromPage(page);
                        await setProducts(products, currentUrl);
                        page.close();
                    }
                } else {
                    let products = await getProductsFromPage(page);
                    let category = await getCategory(page);
                    console.log("category", category);
                    await setCategory(category, products, currentUrl);
                    await setProducts(products, currentUrl);
                    page.close();
                }
            }

            async function getProductsFromPage(page) {
                const productBlock = await page.$$eval('.product-item', function(products) {
                    let prodArrAll = [];
                    prodArrAll['fieldNames'] = [];
                    let fieldNames = [];
                    products.forEach(function (item) {
                        let fields = item.querySelectorAll('.product-classifications__item');
                        fields.forEach(function (field) {
                            let fieldName = field.querySelector('.product-classifications__name');
                            fieldName = fieldName ? fieldName.innerText : "";
                            fieldName = fieldName.replace(":", "");
                            fieldName = fieldName.trim();
                            if(!fieldNames.includes(fieldName)) {
                                fieldNames.push(fieldName);
                            }
                        });
                    });

                    products.forEach(function (item) {
                        let prodArr = {};
                        let prodhead = item.querySelector('.break-word');
                        prodhead = prodhead ? prodhead.innerHTML : "";
                        let produrl = item.querySelector('.product-item__title');
                        produrl = produrl ? produrl.href : "";
                        prodArr['title'] = prodhead;
                        prodArr['slug'] = produrl;
                        prodArr['fields'] = [];
                        let fieldsObj = {};
                        let fields = item.querySelectorAll('.product-classifications__item');
                        fields.forEach(function (field) {
                            let fieldName = field.querySelector('.product-classifications__name');
                            fieldName = fieldName ? fieldName.innerText : "";
                            fieldName = fieldName.replace(":", "");
                            fieldName = fieldName.trim();
                            if(fieldNames.includes(fieldName)) {
                                let fieldValue = field.querySelector('.product-classifications__value');
                                fieldValue = fieldValue ? fieldValue.innerText : "";
                                fieldsObj[fieldName] = fieldValue.trim();
                            }
                        });
                        fieldNames.forEach(function (name) {
                            let keys = Object.keys(fieldsObj);
                            if(!keys.includes(name)) {
                                fieldsObj[name] = "";
                            }
                        });

                        fieldNames.sort();
                        let fieldsObjOrdered = {};
                        Object.keys(fieldsObj).sort().forEach(function(key) {
                            fieldsObjOrdered[key] = fieldsObj[key];
                        });

                        prodArr['fields'].push(fieldsObjOrdered);
                        let stockBlock = item.querySelectorAll('form .product-stock-table__row');

                        prodArr['stoks'] = [];

                        stockBlock.forEach(function (stock) {
                            let stocks = {};
                            let stockName = stock.querySelector('.product-stock-table__column_name');
                            // page.waitForSelector('.product-stock-table__column_name');
                            stockName = stockName ? stockName.innerText : "";
                            let stockPrice = stock.querySelector('.product-stock-table__column_price');
                            stockPrice = stockPrice ? stockPrice.innerText : "";
                            let stockLevel = stock.querySelector('.product-stock-table__column_level');
                            stockLevel = stockLevel ? stockLevel.innerText : "";
                            stocks["Склад"] = stockName.trim();
                            stocks["Цена"] = stockPrice.trim();
                            stocks["Наличие"] = stockLevel.trim();
                            prodArr['stoks'].push(stocks);
                        });
                        prodArr['fieldNames'] = fieldNames;
                        prodArrAll.push(prodArr);
                    });
                    return prodArrAll;
                });

                // productBlock.forEach(function (prod) {
                //     console.log(prod.fields, "product fields");
                //     // console.log(prod.stoks, "product stokcs");
                //     // console.log(prod.stockBlock, "product stokBlock");
                // });

                return productBlock;
            }

            async function getCategory(page) {
                let category = {};
                let breadcrumbs = [];
                let header = await page.$eval('h1', (el) => el ? el.innerHTML : "");
                breadcrumbs = await page.$$eval('.breadcrumbs > a', (breadcrumbs) =>
                    breadcrumbs.map((breadcrumb) => breadcrumb ? breadcrumb.textContent : "")
                );
                let breadcrumpLink = await page.$$eval('.breadcrumbs > a', function(element) {
                    let arr = [];
                    element.forEach(function(elem) {
                        arr.push(elem.href);
                    });
                    return arr;
                });
                breadcrumpLink = breadcrumpLink[breadcrumpLink.length - 1];
                let parentTitle = breadcrumbs[breadcrumbs.length - 1];
                parentTitle = parentTitle.trim();
                category['title'] = header;
                category['url'] = page.url();
                category['parentCategory'] = parentTitle;
                category['parentCategoryLink'] = breadcrumpLink;
                return category;

            }

            async function setCategory(category, products, currentUrl) {
                if(Object.keys(category).length != 0) {
                    let parentCatId = null;
                    let catId;
                    if(category.parentCategoryLink){
                        let parentCat = await getCategoryByLink(category.parentCategoryLink);
                        parentCatId = parentCat[0] ? parentCat[0].id : null;
                    }
                    if(category.url){
                        let cat = await getCategoryByLink(currentUrl);
                        catId = cat[0] ? cat[0].id : null;
                    }

                    //получаем наименования характеристик и конвертим в JSON для записи
                    let fieldNameObject = products ? products[0].fieldNames : [];
                    fieldNameObject.push("Склад", "Цена", "Наличие");
                    fieldNameObject = fieldNameObject ? JSON.stringify(fieldNameObject) : null;
                    let obj = [category.title, parentCatId, 1, fieldNameObject, catId];

                    updateCategory(obj);
                }
            }

            async function setProducts(products, currentUrl) {
                let cat = await getCategoryByLink(currentUrl);
                if(cat[0].id) {
                    products.forEach(function (prod) {
                        prod['stoks'].forEach(function (stock) {
                            let fields = Object.assign(prod['fields'][0], stock);
                            fields = JSON.stringify(fields);
                            obj = {
                                category_id: cat[0].id,
                                title: prod.title,
                                slug: prod.slug,
                                price: "",
                                field: fields,
                                unit: null,
                                sklad_id: skladId
                            };
                            insertOnceProduct(obj);
                        })
                    });

                }
            }

            async function updateCategory(catArr) {
                try {
                    if(catArr.length !== 0) {
                        let query = pool.query('UPDATE `parser_categories` SET title = ?, parent_id = ?, status = ?, fields = ? WHERE id = ?', catArr, function (error, results, fields) {
                            if (error) throw error;
                        });
                    }
                } catch (e) {
                    console.log('error of update obj');
                }
            }

            async function insertOnceProduct(prod) {
                try {
                    if(prod.length !== 0) {
                        let query = pool.query('INSERT INTO `parse_products` SET ?', prod, function (error, results, fields) {
                            if (error) throw error;
                        });
                    }
                } catch (e) {
                    console.log('error of insert obj');
                }
            }

            async function checkOnceProduct(prod) {
                try {
                    let result;
                    let values = prod ? Object.values(prod) : "";
                    if(values) {
                        let result = await query('SELECT * FROM `parser_categories` WHERE category_id = '+ values.category_id +' AND title = ' + values.title + ' AND slug = ' + values.slug + ' AND price = ' + values.price + ' AND field = ' + values.field + ' AND unit = ' + values.unit + ' AND sklad_id = ' + values.sklad_id);
                    }

                    return result ? true : false;
                } catch (e) {
                    console.log("Error read from db getAllCategory")
                }
            }

            async function getPaginateCount(page) {
                const count = await page.$$eval('.page-numbers li', function (p) {
                    if(p.length > 3) {
                        pageCount = p[p.length - 2];
                        pageCount = pageCount.innerText;
                    } else {
                        pageCount = 1;
                    }
                    return pageCount;
                });
                return count;
            }

            function getHeadersFromPage(page) {
                let catLinkObject = page.evaluate(() => {
                    let element = document.querySelector('a');
                    console.log(element, "element");
                    return element;
                });
                console.log(catLinkObject);
                return catLinkObject;
            }

            function getCategoryLinksFromSitemap(skladId, page) {
                let catLinkObject = page.evaluate((skladId) => {
                    let data = []; // Создаём пустой массив для хранения данных
                    let elements = document.querySelectorAll('a'); // Выбираем все товары
                    elements.forEach(function (a) {
                        const href = a.innerHTML;
                        if(href.indexOf("/o/e/") != -1 || href.indexOf("/o/c/") != -1) {
                            obj = {title: "", url: a.innerHTML, parent_id: null, sklad_id: skladId, status: 0};
                            data.push(obj);
                        }
                    });
                    return data; // Возвращаем массив
                }, skladId);
                return catLinkObject;
            }

            async function getCategoryLinksFromCatalog(page) {
                let catLinkObject = page.evaluate((skladId) => {
                    let data = []; // Создаём пустой массив для хранения данных
                    let elements = document.querySelectorAll('.categories .category-list__item a'); // Выбираем все товары

                    elements.forEach(function (a) {
                        const href = a.innerHTML;
                            obj = {title: "", url: a.href, parent_id: null, sklad_id: skladId, status: 0};
                            data.push(obj);
                    });
                    return data; // Возвращаем массив
                }, skladId);

                return catLinkObject;
            }

            async function writeCategoryLinks(catLink, skladId) {
                let categories = await getAllCategory(skladId);
                if(!categories.length) {
                    await insertAllCategory(catLink);
                }
            }

            async function getCategories(skladId) {
                const categoryLinks = await getAllCategory(skladId);
                return categoryLinks;
            }

            async function getAllCategory(skladId) {
                try {
                    let result = await query('SELECT * FROM `parser_categories` WHERE sklad_id = ' + skladId);
                    return result;
                } catch (e) {
                    console.log("Error read from db getAllCategory")
                }
            }

            async function getCategoryByLink(link) {
                try {
                    let result = await query('SELECT * FROM `parser_categories` WHERE sklad_id = ' + skladId + ' AND ' + 'url = ' + '"' + link + '"');
                    return result;
                } catch (e) {
                    console.log("Error read from db getCategoryByLink")
                }
            }

            async function insertAllCategory(catArr) {
                try {
                    if(catArr.length !== 0) {
                        await asyncForEach(catArr, async (value, index) => {
                            await pool.query('INSERT INTO `parser_categories` SET ?', value, function (error, results, fields) {
                                if (error) throw error;
                            });
                        }).then(_ => {
                            console.log('Finish insert category')
                        });
                    }
                } catch (e) {
                    console.log('error of insert obj');
                }
            }

            async function asyncForEach(arr, callback) {
                for(let i = 0; i < arr.length; i++)
                    await callback(arr[i], i, arr)
            }

            async function stopAlert() {
                try {
                    let query = pool.query('DELETE FROM `alerts` WHERE sklad_id = ' + skladId, function (error, results, fields) {
                        if (error) throw error;
                    });
                } catch (e) {
                    console.log('error of update alert');
                }
            }

        }
    }

});

let query = function( sql, values ) {
    // возвращаем обещание
    return new Promise((resolve, reject) => {
        pool.getConnection(function (err, connection) {
            if (err) {
                reject(err)
            } else {
                connection.query(sql, values, (err, rows) => {

                    if (err) {
                        reject(err)
                    } else {
                        resolve(rows)
                    }
                    // завершаем сеанс
                    connection.release()
                })
            }
        })
    })
}

app.listen(port, () => {
    console.log(`Server running at http://${hostname}:${port}/`);
})
